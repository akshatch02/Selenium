package com.capgemini.banking.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import com.capgemini.banking.bean.Account;


public class AccountDaoImpl implements AccountDao {

	
	//static Logger myLogger =Logger.getLogger(AccountDaoImpl.class.getName());
	
	long accno=986798946;
	float minBalance=1000;
	public Account account=null;
	public Account account1=null;
	
	public ArrayList<Account> list;
	{
		
		list=new ArrayList();
	}
	@Override
	public long addAcount(Account a) {
		
		
		accno++;
		a.setAccno(accno);
		a.setTransDate(LocalDate.now());
		list.add(a);
		//myLogger.info("product added to List");
		return accno;
	}
	
	@Override
	public List<Account> showAccDetails() {
		// TODO Auto-generated method stub
		return list;
	}
	@Override
	public float withdraw(float amount,long accno) {
		Iterator<Account> itr=list.iterator();
		float bal=0;
		while(itr.hasNext())
		{
			account=itr.next();
			if(account.getAccno()==accno)
			{
			 bal=account.getBalance();
			 	if(amount<minBalance)
			 		{
			 			bal=bal-amount;
			 			account.setBalance(bal);
			 		}
			 	else
			 	{
			 	System.out.println("insufficient balance");
			 	}
		}
			else
			{
			System.out.println("invalid account number");
			}
		}
		return bal;
	}
	@Override
	public float deposit(float amount,long accno) {
		Iterator<Account> itr=list.iterator();
		float bal=0;
		while(itr.hasNext())
		{
		account=itr.next();
		if(account.getAccno()==accno)
		{
		 bal=account.getBalance();
		bal=bal+amount;
		account.setBalance(bal);
		return bal;
		}
		
		}
		System.out.println("invalid account number");
		return 0;
		
	}

	@Override
	public void fundTransfer(long accno1, long accno2, float amount) {
		Iterator<Account> itr=list.iterator();
		Iterator<Account> iter=list.iterator();
		float bal1=0;
		float bal2=0;
		while(itr.hasNext())
		{
			account=itr.next();
			if(account.getAccno()==accno1)
			{
				while(iter.hasNext())
				{
					account1=iter.next();
				if(account1.getAccno()==accno2)
				{
				bal1=account.getBalance();
				bal1=bal1-amount;
				account.setBalance(bal1);
					if(bal1<minBalance)
						{
						System.out.println("You cant transfer");
						//System.exit(0);
						break;
						}
					else {
						bal2=account1.getBalance();
						bal2=bal2+amount;
						account1.setBalance(bal2);
						System.out.println("Balance of Account "+accno2+" is " +account1.getBalance());
						System.out.println("Balance of Account "+accno1+" is " +account.getBalance());
						System.out.println("Fund Transfer Successful!!!");
						//System.exit(0);
						}
					break;
				}
				else
				{
					System.out.println("Fund Transfer Unsuccesful as "+accno2+" does not exist!!");
					//System.exit(0);
					break;
				}
				
				}
				break;
		}
			else
				{
					System.out.println("Fund Transfer Unsuccesful as "+accno1+" does not exist!!");
					//System.exit(0);
					break;
				}
			
			
		}
		//return bal1;
	
}
}