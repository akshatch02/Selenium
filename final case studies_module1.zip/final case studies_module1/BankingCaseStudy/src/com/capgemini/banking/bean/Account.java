package com.capgemini.banking.bean;

import java.time.LocalDate;

public class Account {

	long accno;
	String fname;
	String lname;
	float balance;
	LocalDate transDate;

	public Account() {
		super();
	}

	public Account(String fname, String lname, float balance) {
		super();
		this.accno = 1000;
		this.fname = fname;
		this.lname = lname;
		this.balance = balance;
	}

	public long getAccno() {
		return accno;
	}

	public void setAccno(long accno) {
		this.accno = accno;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public LocalDate getTransDate() {
		return transDate;
	}

	public void setTransDate(LocalDate transDate) {
		this.transDate = transDate;
	}

	@Override
	public String toString() {
		return "Account [accno=" + accno + ", fname=" + fname + ", lname=" + lname + ", balance=" + balance
				+ ", transDate=" + transDate + "]";
	}



	
}
