package com.capgemini.banking.user;

import java.util.List;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthStyleFactory;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.service.AccountService;
import com.capgemini.banking.service.AccountServiceImpl;


public class SampleProject {

	public static void main(String[] args) {
		AccountService service;
		{
			service=new AccountServiceImpl();
		}
		List list;
		
		Scanner sc=new Scanner(System.in);
		String ans;
		int no;
	
		do
		{
			
			System.out.println("*****Payment Bank*****");
			System.out.println("1.Create account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Display");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Exit");
			System.out.println("Please enter your choice");
			no=sc.nextInt();
			
			switch(no){
			
			case 1:
				System.out.println("Enter your details to create an account");
				System.out.println("Enter the firstname");
				String fname=sc.next();
				System.out.println("Enter the lastname");
				String lname=sc.next();
				System.out.println("Enter the balance");
				float bal=sc.nextFloat();
				Account a=new Account(fname,lname,bal);
				long accno=service.addAcount(a);
				System.out.println("Account no : "+accno);
				break;
			case 2:
				System.out.println("Enter your account no");
				accno=sc.nextLong();
				System.out.println("Enter the amount to be deposited");
				float amount=sc.nextFloat();
				float currentBalnc=service.deposit(amount,accno);
				System.out.println("Your current balance is : "+currentBalnc);
				break;
			
			case 3:
				System.out.println("Enter your account no");
				accno=sc.nextLong();
				System.out.println("Enter the amount to be withdrawn");
				amount=sc.nextFloat();
				currentBalnc=service.withdraw(amount,accno);
				System.out.println("Your current balance is : "+currentBalnc);
				break;
				
			case 4:
				List<Account> accList=service.showAccDetails();
				System.out.println(accList);
				break;
				
				
			case 5:
				System.out.println("Enter the account number from which you want to transfer funds");
				long accno1=sc.nextLong();
				System.out.println("Enter the account number to which you want to transfer funds");
				long accno2=sc.nextLong();
				System.out.println("How much amount do you want to transfer?");
				amount=sc.nextFloat();
				//float bal1=service.fundTransfer(accno1, accno2, amount);
				service.fundTransfer(accno1, accno2, amount);
				//System.out.println("reamining balance of "+accno1+" is "+bal1);
				break;
			default:
			System.out.println("some error in switch case");
			break;
				
				
			}
			
			System.out.println("Do you want to continue yes/no");
			ans=sc.next();
		}while(ans.equals("Yes")||ans.equals("y")||ans.equals("yes"));

	}


	}


