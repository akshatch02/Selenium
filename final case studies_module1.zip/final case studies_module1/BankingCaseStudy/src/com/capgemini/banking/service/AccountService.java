package com.capgemini.banking.service;

import java.util.List;

import com.capgemini.banking.bean.Account;

public interface AccountService {
public abstract long addAcount(Account a);
	
	public abstract float withdraw(float amount,long accno);
	public abstract float deposit(float amount,long accno);
	public List<Account> showAccDetails();
	public abstract void fundTransfer(long accno1,long accno2,float amount);

}
