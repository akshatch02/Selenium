package com.capgemini.banking.service;

import java.util.List;
import java.util.Scanner;

import com.capgemini.banking.bean.Account;
import com.capgemini.banking.dao.AccountDao;
import com.capgemini.banking.dao.AccountDaoImpl;


public class AccountServiceImpl implements AccountService {
	private AccountDao serviceDao;
	
	
	public AccountServiceImpl() {
		serviceDao=new AccountDaoImpl();
	}
	

	@Override
	public long addAcount(Account a) {
	acceptAccDetails(a);	
	long accno=serviceDao.addAcount(a);
	return accno;
	}

	public void acceptAccDetails(Account a) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			String str=a.getFname();
			if(validateName(str))
				break;
			 else
			  {
				  System.err.println("First Name should contain only characters!!Numbers not allowed.First letter should be capital");
				  System.out.println("Enter first name again eg. Ankita");
				  a.setFname(sc.next());
			  }
				
		}
		while(true)
		{
			String str=a.getLname();
			if(validateName(str))
				break;
			 else
			  {
				  System.err.println("Last Name should contain only characters!!Numbers not allowed.First letter should be capital");
				  System.out.println("Enter last name again eg. Sinha");
				  a.setLname(sc.next());
			  }
				
		}
		while(true)
		{
			float bal=a.getBalance();
			if(validateBalance(bal))
				break;
			 else
			  {
				  System.err.println("Minimum Balance should be Rs1000");
				  System.out.println("Enter the balance again");
				  a.setBalance(sc.nextFloat());
			  }
				
		}
		
	}

	public boolean validateBalance(float bal)
	{
		if(bal<1000)
		{
			return false;
		}
		else
			return true;
	}

	public boolean validateName(String pName)
	{
		String pattern="[A-Z][a-zA-Z]*";
		if(pName.matches(pattern))
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	@Override
	public float withdraw(float amount,long accno) {
		float balance=serviceDao.withdraw(amount,accno);
		return balance;
		
	}

	@Override
	public float deposit(float amount,long accno) {
		float balance=serviceDao.deposit(amount,accno);
		return balance;
		
	}
	

	@Override
	public List<Account> showAccDetails() {
		// TODO Auto-generated method stub
		return serviceDao.showAccDetails();
	}


	@Override
	public void fundTransfer(long accno1, long accno2, float amount) {
		//float balance=serviceDao.fundTransfer(accno1, accno2, amount);
		serviceDao.fundTransfer(accno1, accno2, amount);
		//return balance;
	}




	}


