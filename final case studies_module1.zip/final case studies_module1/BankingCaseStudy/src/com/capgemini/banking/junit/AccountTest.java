package com.capgemini.banking.junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.banking.bean.Account;


public class AccountTest {
@Test
public void GetFname()
{
	Account account=new Account("Shiwani","Sinha",20000.00f);
	assertEquals("Shiwani",account.getFname());
}
@Test
public void GetLname()
{
	Account account=new Account("Shiwani","Sinha",20000.00f);
	assertEquals("Sinha",account.getLname());
}
}