package com.capgemini.electricbill.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.electricbill.bean.ElectricBill;

class ElectricBillTest {

	@Test
	public void GetFname() {
		ElectricBill eb=new ElectricBill("Shiwani","Sinha",456.00f,765.99f);
		assertEquals("Shiwani", eb.getFirstName());
		
	}
	@Test
	public void GetLname() {
		ElectricBill eb=new ElectricBill("Shiwani","Sinha",456.00f,765.99f);
		assertEquals("Sinha", eb.getLastName());
		
	}
	@Test
	public void GetPrevReading() {
		ElectricBill eb=new ElectricBill("Shiwani","Sinha",456.00f,765.99f);
		assertEquals(456.00f, eb.getPreviousUnit());
		
	}
	@Test
	public void GetCurrReading() {
		ElectricBill eb=new ElectricBill("Shiwani","Sinha",456.00f,765.99f);
		assertEquals(765.99f, eb.getCurrentUnit());
		
	}

}
