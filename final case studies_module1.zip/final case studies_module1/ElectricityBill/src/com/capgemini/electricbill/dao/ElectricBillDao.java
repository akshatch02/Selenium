package com.capgemini.electricbill.dao;

import java.util.List;

import com.capgemini.electricbill.bean.ElectricBill;

public interface ElectricBillDao {

	public abstract int generateBillNo(ElectricBill eb);
	public abstract float calculateBill(ElectricBill eb);
	public abstract ElectricBill searchBill(int billno);
	public List<ElectricBill> displayDetails(int billno);
}
