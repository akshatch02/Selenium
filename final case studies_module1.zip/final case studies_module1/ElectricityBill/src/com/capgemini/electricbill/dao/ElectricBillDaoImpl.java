package com.capgemini.electricbill.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.electricbill.bean.ElectricBill;

public class ElectricBillDaoImpl implements ElectricBillDao{

	static int billno=1001;
	ElectricBill bill=null;
	public ArrayList<ElectricBill> list;
	{
		list=new ArrayList<ElectricBill>();
	}
	
	@Override
	public int generateBillNo(ElectricBill eb) {
		billno++;
		eb.setBillno(billno);
		list.add(eb);
		return billno;
	}

	@Override
	public float calculateBill(ElectricBill eb) {
		
		float total_bill;
		float rem_unit;
		int bill_no=generateBillNo(eb);
		System.out.println("Your bill no is : "+bill_no);
		rem_unit=eb.getCurrentUnit()-eb.getPreviousUnit();
		if(rem_unit>=200)
		{
			total_bill=rem_unit*20;
			eb.setTotal_bill(total_bill);
		}
		else
		{
			
			total_bill=rem_unit*10;
			eb.setTotal_bill(total_bill);
		}
		
		return total_bill;
		
		
	}

	@Override
	public List<ElectricBill> displayDetails(int billno) {
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public ElectricBill searchBill(int billno) {
		Iterator<ElectricBill> itr=list.iterator();
		while(itr.hasNext())
		{
			bill=itr.next();
			if(bill.getBillno()==billno)
			{
				return bill;
			}
			else
			{
				return null;
			}
		}
		
		return null;
	}




}
