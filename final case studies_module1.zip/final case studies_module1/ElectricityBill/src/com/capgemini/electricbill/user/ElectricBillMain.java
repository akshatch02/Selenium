package com.capgemini.electricbill.user;

import java.util.List;
import java.util.Scanner;

import com.capgemini.electricbill.bean.ElectricBill;
import com.capgemini.electricbill.service.ElectricBillService;
import com.capgemini.electricbill.service.ElectricBillServiceImpl;

public class ElectricBillMain {

	public static void main(String[] args) {
	 ElectricBillService service;
	{
		service=new ElectricBillServiceImpl();
	}
		Scanner sc=new Scanner(System.in);
		int choice;
		String answer;
		do {
			
		
		System.out.println("********Electric Bill********");
		System.out.println("1.Generate Bill");
		System.out.println("2.Display");
		System.out.println("Please enter your choice : ");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter the first name : ");
			String fName=sc.next();
			System.out.println("Enter the last name : ");
			String lName=sc.next();
			System.out.println("Enter the previous unit : ");
			float prevUnit=sc.nextFloat();
			System.out.println("Enter the current unit : ");
			float currUnit=sc.nextFloat();
			ElectricBill bill=new ElectricBill(fName,lName,prevUnit,currUnit);
			//int billno=service.generateBillNo(bill);
			//System.out.println(billno);
			float totalbill=service.calculateBill(bill);
			System.out.println("Total bill is : "+totalbill);
			break;
		case 2:
			System.out.println("Enter your bill no");
			int billno=sc.nextInt();
			List<ElectricBill> list=service.displayDetails(billno);
			System.out.println(list);
			break;
			
		}
		System.out.println("Do you want to continue?");
		answer=sc.next();
		}while(answer.equals("yes")||answer.equals("y")||answer.equals("Yes"));
	}

}
