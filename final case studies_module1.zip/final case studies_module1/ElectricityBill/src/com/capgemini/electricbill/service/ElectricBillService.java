package com.capgemini.electricbill.service;

import java.util.List;

import com.capgemini.electricbill.bean.ElectricBill;

public interface ElectricBillService {

	public abstract int generateBillNo(ElectricBill eb);
	public abstract float calculateBill(ElectricBill eb);
	public abstract ElectricBill searchBill(int billno);
	public List<ElectricBill> displayDetails(int billno);
}
