package com.capgemini.electricbill.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.electricbill.bean.ElectricBill;
import com.capgemini.electricbill.dao.ElectricBillDao;
import com.capgemini.electricbill.dao.ElectricBillDaoImpl;

public class ElectricBillServiceImpl implements ElectricBillService {

	//ArrayList<ElectricBill> list;
	public ElectricBillDao serviceDao;
	{
		serviceDao=new ElectricBillDaoImpl();
	}
	
	@Override
	public int generateBillNo(ElectricBill eb) {
		int billno=serviceDao.generateBillNo(eb);
		return billno;
	}

	@Override
	public float calculateBill(ElectricBill eb) {
		float t_bill=serviceDao.calculateBill(eb);
		return t_bill;
	}

	@Override
	public ElectricBill searchBill(int billno) {
		ElectricBill ebill=serviceDao.searchBill(billno);
		return ebill;
	}

	@Override
	public List<ElectricBill> displayDetails(int billno) {
	
		return serviceDao.displayDetails(billno);
	}

}
