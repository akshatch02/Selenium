package com.capgemini.electricbill.bean;

public class ElectricBill {
	String firstName;
	String lastName;
	float previousUnit;
	float currentUnit;
	int billno;
	float total_bill;
	
	
	public ElectricBill() {
		super();
	}



	public ElectricBill(String firstName, String lastName, float previousUnit, float currentUnit) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.previousUnit = previousUnit;
		this.currentUnit = currentUnit;
	}



	


	public ElectricBill(String firstName, String lastName, float previousUnit, float currentUnit, float total_bill) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.previousUnit = previousUnit;
		this.currentUnit = currentUnit;
		this.total_bill = total_bill;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public float getPreviousUnit() {
		return previousUnit;
	}



	public void setPreviousUnit(float previousUnit) {
		this.previousUnit = previousUnit;
	}



	public float getCurrentUnit() {
		return currentUnit;
	}



	public void setCurrentUnit(float currentUnit) {
		this.currentUnit = currentUnit;
	}



	public int getBillno() {
		return billno;
	}



	public void setBillno(int billno) {
		this.billno = billno;
	}



	public float getTotal_bill() {
		return total_bill;
	}



	public void setTotal_bill(float total_bill) {
		this.total_bill = total_bill;
	}



	@Override
	public String toString() {
		return "****Electricity Bill****\n"+"Bill No :\t" + billno + "\nFirstName :\t" + firstName + "\nLastName :\t" + lastName + "\nPrevious Unit :\t" + previousUnit
				+ "\nCurrent Unit :\t" + currentUnit +"\nTotal Bill :\t"+total_bill+"\n";
	}



	
	
	
	

}
