package com.capgemini.core.salary.service;

import com.capgemini.core.salary.bean.Employee;
import com.capgemini.core.salary.exception.EmployeeException;
import com.capgemini.core.salary.model.EmployeeDAO;
import com.capgemini.core.salary.model.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService
{
	
	
	private EmployeeDAO employeeDAO;
	
	public  EmployeeServiceImpl() 
	{

		//association-(link)
		employeeDAO=new EmployeeDAOImpl();
	
	}
	

	@Override
	public Employee getEmployee(int empId) throws EmployeeException {

		Employee employee=null;
		
		employee=employeeDAO.getEmployee(empId);
		return employee;
	}
	
	

	@Override
	public float calculateSalary(int empId, int days) throws EmployeeException 
	{
		float sal=employeeDAO.calculateSalary(empId, days);
		return sal;
		
	}

}
