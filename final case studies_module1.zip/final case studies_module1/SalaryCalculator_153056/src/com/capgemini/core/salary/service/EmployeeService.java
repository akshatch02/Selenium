package com.capgemini.core.salary.service;

import com.capgemini.core.salary.bean.Employee;
import com.capgemini.core.salary.exception.EmployeeException;

public interface EmployeeService 
{
	public Employee getEmployee(int empId) throws EmployeeException;
	
	public float calculateSalary(int empId, int days) throws EmployeeException;
}
