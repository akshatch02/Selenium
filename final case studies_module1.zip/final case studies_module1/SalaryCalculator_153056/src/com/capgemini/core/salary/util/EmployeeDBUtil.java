package com.capgemini.core.salary.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.core.salary.bean.Employee;

public class EmployeeDBUtil {
	

	Map<Integer,Employee> emp=new HashMap<Integer, Employee>();
	{ 
		
		emp.put(1011, new Employee(1011, "John", "Security",600400));
		emp.put(3433, new Employee(3433, "Eric", "Accounts",600500));
		emp.put(8734, new Employee(8734, "Peter", "Accounts",500500));
	    emp.put(8732, new Employee(8732, "Anna", "R&D",850300));
	    emp.put(8734, new Employee(8734, "Jane", "Security",445000));
			
	}
	public Map<Integer, Employee> getEmp() {
		return emp;
	}
	public void setEmp(Map<Integer, Employee> emp) {
		this.emp = emp;
	}

	
	
}
