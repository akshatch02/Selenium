package com.capgemini.core.salary.view;

import java.util.Scanner;


import com.capgemini.core.salary.bean.Employee;
import com.capgemini.core.salary.exception.EmployeeException;
import com.capgemini.core.salary.service.EmployeeService;
import com.capgemini.core.salary.service.EmployeeServiceImpl;

public class Client {
	
private EmployeeService empService;
	
	public Client()
	{
		//association-linking to service
		empService=new EmployeeServiceImpl();
	}
	
	
	public void menu()
	{
		System.out.println("1) View Information");
		System.out.println("2) cal emp salary");
		System.out.println("3) exit");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please select an option: ");
		int choice=sc.nextInt();
		
		switch(choice)
		{
		
	case 1:
		
		System.out.println("Enter emp ID to view details: ");
		int empId=sc.nextInt();
		
		try {
			Employee employee = empService.getEmployee(empId);
			
			System.out.println("Id: "+ employee.getId());
			System.out.println("name: " + employee.getName());
			System.out.println("department: "+ employee.getDepartment());
			System.out.println("salary: "+ employee.getSalary());
		} 
		catch (EmployeeException e1) 
		{
			
			System.out.println(e1.getMessage());
		}
		catch (Exception e1) 
		{
			
			e1.getMessage();
		}
		break;

		
	case 2:
		System.out.println("enter employee id to calculate salary: ");
		int emId=sc.nextInt();
		
		System.out.println("enter no of days present for current month: ");
		int days=sc.nextInt();
		
			try 
			{
				float sal=empService.calculateSalary(emId,days);
				System.out.println("Salary for employye Id "+emId +"is " +sal+"for " +days+"days");
			} 
			catch (EmployeeException e) 
			{
				
				e.printStackTrace();
			}
			break;
			
	case 3:
		System.out.println("GoodBye");
		System.exit(0);
		break;
		
	default:
		System.out.println("Invalid Option");
		break;
		
}
		
}
	public static void main(String[] args) {

			Client client=new Client();
			
			while(true)
				client.menu();
		}
			
			
		}		

	
	


