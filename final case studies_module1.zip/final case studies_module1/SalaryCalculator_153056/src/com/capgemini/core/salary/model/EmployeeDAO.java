package com.capgemini.core.salary.model;

import java.awt.print.Book;

import com.capgemini.core.salary.bean.Employee;
import com.capgemini.core.salary.exception.EmployeeException;

public interface EmployeeDAO 
{
	public Employee getEmployee(int empId) throws EmployeeException;
	
	public float calculateSalary(int empId, int days) throws EmployeeException;
}
