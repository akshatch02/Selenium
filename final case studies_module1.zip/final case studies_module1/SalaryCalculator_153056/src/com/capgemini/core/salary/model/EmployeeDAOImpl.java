package com.capgemini.core.salary.model;

import java.util.HashMap;
import java.util.Map;


import com.capgemini.core.salary.bean.Employee;
import com.capgemini.core.salary.exception.EmployeeException;
import com.capgemini.core.salary.util.EmployeeDBUtil;



public class EmployeeDAOImpl implements EmployeeDAO
{
	Map<Integer,Employee> emp=new HashMap<Integer, Employee>();
	EmployeeDBUtil dbutil=new EmployeeDBUtil();
	
	public EmployeeDAOImpl() 
	{
		emp=dbutil.getEmp();
	}
	
	

	@Override
	public Employee getEmployee(int empId) throws EmployeeException {
		
         Employee employee=emp.get(empId);
		
		if(employee==null)
			throw new EmployeeException("employee not found with id" +empId);
		
		return employee;
	
	}

	@Override
	public float calculateSalary(int empId, int days) throws EmployeeException {
	     Employee employee=emp.get(empId);
	     if(employee==null)
				throw new EmployeeException("employee not found with id" +empId);
		
	   float salary= employee.getSalary();
	   float monsalary=salary/12;
	   float daysalary= monsalary/30;
	   float sal=days*daysalary;
	     return sal;
	}

}
