package com.capgemini.core.util;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.gc.beans.Agency;

public class DBUtill {
	
	private List<Agency> agency =new ArrayList<Agency>();
	{
		agency.add(new Agency("jyoti", "Mumbai",45));
		agency.add(new Agency("HP","Pune",12));
		agency.add(new Agency("NewHP","Chennai",34));
		
	}
	public List<Agency> getAgency() {
		return agency;
	}
	public void setAgency(List<Agency> agency) {
		this.agency = agency;
	}
	
	

}
