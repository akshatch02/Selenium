package com.capgemini.core.gc.view;

public class Client {
	

}
