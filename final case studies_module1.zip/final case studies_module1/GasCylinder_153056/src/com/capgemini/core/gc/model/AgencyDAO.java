package com.capgemini.core.gc.model;


import java.util.List;

import com.capgemini.core.gc.beans.Agency;
import com.capgemini.core.gc.exception.GasException;



public interface AgencyDAO {
	
	public List<Agency> getAvailability() throws GasException;
	  
	public int Booking(String name, int count) throws GasException; 

}
