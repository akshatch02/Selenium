 package com.capgemini.core.gc.model;

import java.util.List;

import com.capgemini.core.gc.beans.Agency;
import com.capgemini.core.gc.exception.GasException;
import com.capgemini.core.util.DBUtill;

public class AgencyDAOImpl implements AgencyDAO{
	private List<Agency> agency;
	private DBUtill dbUtill=new DBUtill();
	
	private int bookingno=1000;
	
	
	public  AgencyDAOImpl	()
	{
		agency=dbUtill.getAgency();
	}
	public int generateBookingNo()
	{
	  return ++bookingno;
	}
	
	
	
	

	@Override
	public List<Agency> getAvailability() throws GasException {
		
		return agency;
	}
	

	@Override
	public int Booking(String name, int count) throws GasException {
		int index= agency.indexOf(new Agency(name));
	
		if(index==-1)
		{
			throw new GasException("agency not found with name"+name);
			
		}
		if(agency.get(index).getCount()<count)
		{
			return 0;
		}
		else
		{
			Agency old=agency.get(index);
			int newCount=agency.get(index).getCount()-count;
			old.setCount(newCount);
			
			int bookingno=generateBookingNo();
			return bookingno;
		}
		
	}
}
		
		
		
		
		
		
		
		