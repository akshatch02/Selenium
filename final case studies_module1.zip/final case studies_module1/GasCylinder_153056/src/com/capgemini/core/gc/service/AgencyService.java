package com.capgemini.core.gc.service;

import java.util.List;

import com.capgemini.core.gc.beans.Agency;
import com.capgemini.core.gc.exception.GasException;

public interface AgencyService {
	

	public List<Agency> getAvailability() throws GasException;
	  
	public int Booking(String name, int count) throws GasException; 
	
	public boolean isValid(Agency agency) throws GasException; 


}
