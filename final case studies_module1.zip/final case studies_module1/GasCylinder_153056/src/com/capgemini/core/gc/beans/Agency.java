package com.capgemini.core.gc.beans;

import java.util.Date;

public class Agency {
	
	
	private String name;
	private String location;
	private int count;
	
	
	public Agency(String name, String location, int count) {
		super();
		this.name = name;
		this.location = location;
		this.count = count;
	}
	
	


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}




	public Agency() {
		super();
	}




	public Agency(String name2) {
		this.name=name2;
	}


	
	
	
	
	
	
	
	

}
