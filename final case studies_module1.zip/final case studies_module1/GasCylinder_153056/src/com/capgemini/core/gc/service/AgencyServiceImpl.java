package com.capgemini.core.gc.service;

import java.util.List;

import com.capgemini.core.gc.beans.Agency;
import com.capgemini.core.gc.exception.GasException;
import com.capgemini.core.gc.model.AgencyDAO;
import com.capgemini.core.gc.model.AgencyDAOImpl;

public class AgencyServiceImpl implements AgencyService
{
  private AgencyDAO cylDAO;
  
  public AgencyServiceImpl() {
	  cylDAO= new AgencyDAOImpl();
}
  
  
	@Override
	public List<Agency> getAvailability() throws GasException 
	{
		
		List<Agency> cylinders=null;
		cylinders=cylDAO.getAvailability();
		return cylinders;
	}

	@Override
	public int Booking(String name, int count) throws GasException
	{
	int bookingno=cylDAO.Booking(name, count);
		return 0;
	}

	@Override
	public boolean isValid(Agency agency) throws GasException 
	{

		return false;
	}
	
	
	

}
