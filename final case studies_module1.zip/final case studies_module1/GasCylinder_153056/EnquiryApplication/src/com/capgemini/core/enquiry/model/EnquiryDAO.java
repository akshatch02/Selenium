package com.capgemini.core.enquiry.model;

import com.capgemini.core.enquiry.beans.Enquiry;
import com.capgemini.core.enquiry.exception.EnquiryException;

public interface EnquiryDAO 
{
	public int addEnquiry(Enquiry enquiry) throws EnquiryException;
	
	public Enquiry getEnquiry(int id) throws EnquiryException;

}
