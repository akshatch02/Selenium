package com.capgemini.core.enquiry.beans;

public class Enquiry 
{
	private int id;
	private String firdtname;
	private String lastname;
	private String gender;
	
	private String TechnologyIntrested;
	public Enquiry() {
		super();
	}
	
	public Enquiry(int id) {
		super();
		this.id = id;
	}

	public Enquiry(String firdtname, String lastname, String gender, String technologyIntrested) {
		super();
		this.firdtname = firdtname;
		this.lastname = lastname;
		this.gender = gender;
		TechnologyIntrested = technologyIntrested;
	}

	public Enquiry(int id, String firdtname, String lastname, String gender, String technologyIntrested) {
		super();
		this.id = id;
		this.firdtname = firdtname;
		this.lastname = lastname;
		this.gender = gender;
		TechnologyIntrested = technologyIntrested;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirdtname() {
		return firdtname;
	}
	public void setFirdtname(String firdtname) {
		this.firdtname = firdtname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTechnologyIntrested() {
		return TechnologyIntrested;
	}
	public void setTechnologyIntrested(String technologyIntrested) {
		TechnologyIntrested = technologyIntrested;
	}
	@Override
	public String toString() {
		return "Enquiry [id=" + id + ", firdtname=" + firdtname + ", lastname=" + lastname + ", gender=" + gender
				+ ", TechnologyIntrested=" + TechnologyIntrested + "]";
	}

	

	

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Enquiry other = (Enquiry) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
	

}
