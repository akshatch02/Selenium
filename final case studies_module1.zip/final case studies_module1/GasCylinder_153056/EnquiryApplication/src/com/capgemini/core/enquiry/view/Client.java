package com.capgemini.core.enquiry.view;

import java.util.Scanner;

import com.capgemini.core.enquiry.beans.Enquiry;
import com.capgemini.core.enquiry.exception.EnquiryException;
import com.capgemini.core.enquiry.service.EnquiryService;
import com.capgemini.core.enquiry.service.EnquiryServiceImpl;

public class Client 
{
	EnquiryService enqservice;
	
	public Client()
	{
		//association-linking to service
		enqservice=new EnquiryServiceImpl();
	}
	
	public void menu()
	{
		System.out.println("1) Add Enquiry: ");
		System.out.println("2) Get Enquiry Information");
		System.out.println("0) Exit Application");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please select an option: ");
		int choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:
			Enquiry enquiry=new Enquiry();
			
			System.out.println("1) Enter first name: ");
			String fname=sc.next();
			
			System.out.println("2) Enter last name: ");
			String lname=sc.next();
			
			System.out.println("3) Enter gender: ");
			String gen=sc.next();
			
			System.out.println("4) Enter technology: ");
			String tech=sc.next();
			
			
			enquiry.setFirdtname(fname);
			enquiry.setLastname(lname);
			enquiry.setGender(gen);
			enquiry.setTechnologyIntrested(tech);
			
			try
			{
			int enqId = enqservice.addEnquiry(enquiry);
			
			System.out.println("Enquiry added successfully, Enquiry ID: "+enqId);
			}
			catch(EnquiryException e)
			{
				e.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
				
			}
			break;
		
		
		case 2:
			System.out.println("Enter enquiry ID to view details: ");
			int enqId=sc.nextInt();
			
			try {
				enquiry = enqservice.getEnquiry(enqId);
				
				System.out.println("Id: "+ enquiry.getId());
				System.out.println("First Name: "+ enquiry.getFirdtname());
				System.out.println("Last Name: "+ enquiry.getLastname());
				System.out.println("Gender: "+ enquiry.getGender());
				System.out.println("Technolgy Interested: "+ enquiry.getTechnologyIntrested());
				
			} 
			catch (EnquiryException e1) 
			{
				
				e1.printStackTrace();
			}
			catch (Exception e1) 
			{
				
				e1.printStackTrace();
			}
			break;
			
		case 0:
			System.out.println("goodbye");
			
		}
}
public static void main(String[] args) {
		
		Client client=new Client();
		
		while(true)
			client.menu();
	}
}
