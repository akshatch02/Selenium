package com.capgemini.core.enquiry.service;

import com.capgemini.core.enquiry.beans.Enquiry;
import com.capgemini.core.enquiry.exception.EnquiryException;

public interface EnquiryService 
{
	public int addEnquiry(Enquiry enquiry) throws EnquiryException;
	
	public Enquiry getEnquiry(int id) throws EnquiryException;
}
