package com.capgemini.core.enquiry.service;


import java.util.ArrayList;


import com.capgemini.core.enquiry.beans.Enquiry;
import com.capgemini.core.enquiry.exception.EnquiryException;
import com.capgemini.core.enquiry.model.EnquiryDAO;
import com.capgemini.core.enquiry.model.EnquiryDAOImpl;


public class EnquiryServiceImpl implements EnquiryService
{
	private EnquiryDAO enquiryDAO;
	
	
	ArrayList<Enquiry> enquiries=new ArrayList<Enquiry>();
	

	public EnquiryServiceImpl() 
	{
		enquiryDAO=new EnquiryDAOImpl();
	}

	@Override
	public int addEnquiry(Enquiry enquiry) throws EnquiryException 
	{
		
//		if(enquiry==null)
//			throw new NullPointerException();
//	
//		if(enquiry.getFirdtname()==null && enquiry.getLastname()==null && enquiry.getGender()==null && enquiry.getTechnologyIntrested()==null)
//			throw new IllegalArgumentException();
//
//		
//		System.out.println(enquiries.contains(enquiry));
//		
//		if(enquiries.contains(enquiry))
//		{
//			System.out.println("Exception thrown.");
//			throw new EnquiryException("Data already exists.");
//			}
		
//		enquiries.add(enquiry);
//		return 1;	
		
		int enqId=0;
		if(isValid(enquiry)==true);
		enqId=enquiryDAO.addEnquiry(enquiry);
		return enqId;
		
	
	}

	@Override
	public Enquiry getEnquiry(int id) throws EnquiryException 
	{
		Enquiry enquiry=null;
		
		
		enquiry=enquiryDAO.getEnquiry(id);
		return enquiry;
	}
	

	public boolean isValid( Enquiry enquiry) throws EnquiryException 
	{
		if( enquiry == null)
			throw new EnquiryException( "enquiry instance cannot be null" );
		
		if( enquiry.getFirdtname() == null || enquiry.getFirdtname().trim().isEmpty() )
			throw new EnquiryException( "first Name Cannot be Empty" );
		
		if( enquiry.getLastname() == null || enquiry.getLastname().trim().isEmpty() )
			throw new EnquiryException( "last Name Cannot be Empty" );
		
		if( enquiry.getGender() == null || isGenderInvalid( enquiry.getGender() ) ) 
			throw new EnquiryException( "Gender can only be Male or Female" );

		return true;
}
	
	public static boolean isGenderInvalid(String gender) 
	{
		gender = gender.toLowerCase();
		
		if( !gender.matches("^male$|^female$"))
			return true;	
		else
			return false;
	}
}
