package com.capgemini.core.enquiry.util;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.enquiry.beans.Enquiry;


public class DBUtil 
{
	private List<Enquiry> enquiries=new ArrayList<Enquiry>();
	{
		enquiries.add(new Enquiry( 101,"akshat","chawla","male","nothing"));
		enquiries.add(new Enquiry( 102,"bhagyashri","bobade","female","everything"));
		enquiries.add(new Enquiry( 103,"akhil","kapoor","male","nothing"));
		
		
	}
	
	public List<Enquiry> getEnquiries() {
		return enquiries;
	}
	public void setEnquiries(List<Enquiry> enquiries) {
		this.enquiries = enquiries;
	}
	
	

}
