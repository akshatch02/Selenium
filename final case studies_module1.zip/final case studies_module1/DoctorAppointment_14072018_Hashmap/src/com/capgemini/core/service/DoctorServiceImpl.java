package com.capgemini.core.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.capgemini.core.beans.Doctor;

import com.capgemini.core.exception.DoctorsException;

import com.capgemini.core.model.DoctorDAO;
import com.capgemini.core.model.DoctorDAOImpl;

public class DoctorServiceImpl implements DoctorService
{
	public DoctorDAO docDAO;
	
	public  DoctorServiceImpl()
	
	{
		docDAO=new DoctorDAOImpl();
	}
		
	     
			@Override
			public int addPatientDetails(Doctor doc) throws DoctorsException 
			{
				int appId=0;   
				if(isValid(doc)==true);
		   		appId=docDAO.addPatientDetails(doc);
		   		return appId;
			}
		
		       @Override
				public Doctor getAppointmentDetails(int appId) throws DoctorsException 
				{
		    	   Doctor doctor=null;
		    	doctor=docDAO.getAppointmentDetails(appId);
		    	return doctor;
				}
		       
		       public boolean isValid(Doctor appointment) throws DoctorsException 
		   	{
		   		if( appointment == null)
		   			throw new DoctorsException( "Appointment instance cannot be null" );
		   		
		   		if( appointment.getPatientName() == null || appointment.getPatientName().trim().isEmpty() )
		   			throw new DoctorsException( "Patient Name Cannot be Empty" );
		   		
//		   		if( appointment.getPhoneNumber() == null ||  isPhoneNumberInvalid( appointment.getPhoneNumber() ) )
//		   			throw new DoctorsException( "Phone Number is invalid" );
		   		
		   		if( appointment.getEmail() == null || isEmailInvalid( appointment.getEmail() ) )
		   			throw new DoctorsException( "Email has to be a valid email" );
		   		
//		   		if( !(appointment.getAge() > 1 && appointment.getAge() <= 120) )
//		   			throw new AppointmentException( "Age has to be between 1 to 120" );
		   		
		   		if( appointment.getGender() == null || isGenderInvalid( appointment.getGender() ) ) 
		   			throw new DoctorsException( "Gender can only be Male or Female" );
		   		
		   		if( appointment.getProblemName() == null ||  appointment.getProblemName().trim().isEmpty() )
		   			throw new DoctorsException( "Problem cannot be blank" );
		   		
//		   		if( appointment.getAppointmentDate() == null ||  isDateInvalid( appointment.getAppointmentDate() ) )
//		   			throw new DoctorsException( "AppointmentRequest date has to be greater then current date" );
		   		
		   		return true;
		   	}
		   	
//		   	public boolean isDateInvalid(Date date) 
//		   	{
//		   		if( date.compareTo( new Date() ) <= 0)
//		   			return true;
//		   		else
//		   			return false;
//		   	}

		   	public static boolean isGenderInvalid(String gender) 
		   	{
		   		gender = gender.toLowerCase();
		   		
		   		if( !gender.matches("^male$|^female$"))
		   			return true;	
		   		else
		   			return false;
		   	}
		   	
		   	public boolean isEmailInvalid( String email ) {
		   		
		   		if( email.matches(".+\\@.+\\..+") ) 
		   		{
		   			return false;
		   		}		
		   		else 
		   			return true;
		   	}

		   	public static boolean isPhoneNumberInvalid( String phoneNumber )
		   	{
		   		if(phoneNumber.matches("[1-9][0-9]{9}")) 
		   		{
		   			return false;
		   		}		
		   		else 
		   			return true;
		   	}
		   	
		   	public Date getDateFromString( String dateInString )
		   	{
		   		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		   		LocalDate localDate = LocalDate.parse(dateInString , formatter);

		   		java.util.Date date = java.sql.Date.valueOf( localDate );

		   		return date;
		   	}
				
		       
		       
		}
	
	
	

