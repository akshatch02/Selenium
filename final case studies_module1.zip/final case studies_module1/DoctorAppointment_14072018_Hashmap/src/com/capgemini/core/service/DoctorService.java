package com.capgemini.core.service;

import com.capgemini.core.beans.Doctor;
import com.capgemini.core.exception.DoctorsException;

public interface DoctorService
{
public int addPatientDetails(Doctor doc) throws DoctorsException;
	
	public Doctor getAppointmentDetails(int appId) throws DoctorsException;
}
