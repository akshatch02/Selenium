package com.capgemini.core.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.capgemini.core.beans.Doctor;
import com.capgemini.core.exception.DoctorsException;
import com.capgemini.core.service.DoctorService;
import com.capgemini.core.service.DoctorServiceImpl;

public class Client 
{
	 private  DoctorService docservice;
		
		public Client() 
		{
			//association-linking to service
			docservice=new DoctorServiceImpl();
		}
		public void menu()
		{
			System.out.println("1) Add appointment information");
			System.out.println("2) Get appointment information");
			System.out.println("0) exit");
			
			Scanner console=new Scanner(System.in);
			
			System.out.println("\n please select an option:");
			int choice=console.nextInt();
			
			switch (choice)
			{
			case 1:
				Doctor doc=new Doctor();
				
				System.out.println("1) Enter patient name:");
				String name=console.next();
				
				System.out.println("2) enter email:");
				String email=console.next();
				
				System.out.println("3) enter age:");
				int age=console.nextInt();
				
				System.out.println("4) enter gender");
				String gen=console.next();
				
				System.out.println("5) problem name");
				String probname=console.next();
				
				System.out.println(" Enter patient appointment date(dd-MM-yyyy)");
				String appdate=console.next();
				
				
				doc.setPatientName(name);
				doc.setAge(age);
				doc.setEmail(email);
				doc.setGender(gen);
				doc.setProblemName(probname);
				doc.setAppointmentDate(convertToDate(appdate));
				
					
					try {
						int appId=docservice.addPatientDetails(doc);
						System.out.println("app added successfully, app ID"+appId);
					} catch (DoctorsException e) {
					
						System.out.println("something went wrong " +e);
					}
					catch (Exception e) {
						System.out.println("something went wrong " +e);
					}
					
				
				break;
			case 2:
				System.out.println("enter appid to view details");
				int id=console.nextInt();
				
				try {
				 doc=docservice.getAppointmentDetails(id);
					
					System.out.println("Patient's Name: "+doc.getPatientName());
					System.out.println("Appointment Status: "+doc.getAppointmentStatus());
					System.out.println("Doctor Name: "+doc.getDoctorName());
					System.out.println("Appointment Date: "+doc.getAppointmentDate());
				
			}catch(DoctorsException e1) {
				System.out.println("something went wrong "+e1);
			}catch(Exception e1) {
				System.out.println("something went wrong "+e1);
				 
				
			}
				
				
			break;
			
			case 0:
				System.out.println("GoodBye");
				System.exit(0);
				break;
				
				
			}
			
		}	
		public LocalDate convertToDate(String dateInString)
		{
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
			LocalDate localdate=LocalDate.parse(dateInString,formatter);
		//	java.util.Date date=java.sql.Date.valueOf(localdate);
			return localdate;

		}
		
		public static void main(String[] args) 
		{
			
			Client client=new Client();
			while(true)
				client.menu();
		
}
}

