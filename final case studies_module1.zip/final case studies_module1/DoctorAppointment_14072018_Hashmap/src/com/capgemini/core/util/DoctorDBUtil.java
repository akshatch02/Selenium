package com.capgemini.core.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.core.beans.Doctor;


public class DoctorDBUtil
{
	Map<String,Doctor> doct=new HashMap<String, Doctor>();
	{
		doct.put("Heart", new Doctor( "Bhagyashri"));
		doct.put("gyna", new Doctor( "jkh"));
		doct.put("hkj", new Doctor( "Bhajfdhgf"));
	}
	public Map<String, Doctor> getDoct() {
		return doct;
	}
	public void setDoct(Map<String, Doctor> doct) {
		this.doct = doct;
	}
	
	

}
