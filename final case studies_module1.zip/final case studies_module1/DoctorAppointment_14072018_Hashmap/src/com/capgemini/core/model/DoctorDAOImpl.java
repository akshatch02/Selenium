package com.capgemini.core.model;

import java.util.HashMap;
import java.util.Map;


import com.capgemini.core.beans.Doctor;
import com.capgemini.core.exception.DoctorsException;
import com.capgemini.core.util.DoctorDBUtil;



public class DoctorDAOImpl implements DoctorDAO
{
	Map<String,Doctor> doct=new HashMap<String, Doctor>();
	Map<Integer, Doctor> patient=new HashMap<Integer, Doctor>();
	 DoctorDBUtil docDBUtil = new DoctorDBUtil();
	 
	 
	 
	 public DoctorDAOImpl() 
	 {
		doct=docDBUtil.getDoct();
		
	}
	 
	 
	 
	 
	//returns any value between 1 to 10000
		public int generateDoctorRand()
		{
			double rndDouble=Math.random();
			
			return (int)(rndDouble*10000);
		}

	@Override
	public int addPatientDetails(Doctor doc) throws DoctorsException
	{
	int appId = generateDoctorRand();
	doc.setAppointmentId(appId);
	String problem=doc.getProblemName();
	
	if(doct.containsKey(problem))
	{
	Doctor d = doct.get(problem);
	String docname=d.getDoctorName();
	doc.setDoctorName(docname);
	doc.setAppointmentStatus("approved");
	patient.put(appId, doc);
	
	System.out.println("Patient Name: "+doc.getPatientName());
	System.out.println("Appointment Status: "+doc.getAppointmentStatus());
	System.out.println("Doctor Name: "+doc.getDoctorName());
	
	System.out.println("Your appointment is approved having request Id: "+appId);
	
	}
	else
	{
	
	doc.setAppointmentStatus("disapproved");
	doc.setDoctorName(" ");
	patient.put(appId, doc);
	
	System.out.println("Patient Name: "+doc.getPatientName());
	System.out.println("Appointment Status: "+doc.getAppointmentStatus());
	System.out.println("Doctor Name: "+" ");
		
		
	}
	return appId;
		
	}

	@Override
	public Doctor getAppointmentDetails(int appId) throws DoctorsException
	{
		Doctor doc=patient.get(appId);
	if(doc==null)
		throw new DoctorsException("appointment not found");
	return doc;
		
	}
	

}
