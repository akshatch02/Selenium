package com.capgemini.core.model;

import com.capgemini.core.beans.Doctor;
import com.capgemini.core.exception.DoctorsException;

public interface DoctorDAO 
{
    public int addPatientDetails(Doctor doc) throws DoctorsException;
	
	public Doctor getAppointmentDetails(int appId) throws DoctorsException;
}
