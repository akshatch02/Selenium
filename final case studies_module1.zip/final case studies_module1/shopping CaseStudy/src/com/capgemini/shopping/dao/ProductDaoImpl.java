package com.capgemini.shopping.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.shopping.bean.Product;
import com.capgemini.shopping.exception.CustomExp;

public class ProductDaoImpl implements ProductDao {
	int prdId = 10000;
	Product product=null;
	static Logger myLogger=Logger.getLogger(ProductDaoImpl.class.getName());
	public ArrayList<Product> list;
	{
		list = new ArrayList();
	}

	@Override
	public int addProduct(Product p) throws CustomExp {
		try {
		if(p==null)
			throw new Exception();
		prdId++;
		p.setId(prdId);
		p.setTransDate(LocalDate.now());
		list.add(p);
		myLogger.debug("Debug info:Product added to list");
	myLogger.info("product added in a list");
		return prdId;
		}
		catch(Exception e)
		{
			throw new CustomExp("Sorry could not add a record",e);
		}
	}

	@Override
	public List<Product> listAllProductRecords() {
		// TODO Auto-generated method stub
		
		return list;
	}

	@Override
	public Product getProductById(int pId) {

		Iterator<Product> itr=list.iterator();
		while(itr.hasNext())
		{
			product=itr.next();
			if(product.getId()==pId)
			{
				return product;
			}
			else
			{
				return null;
			}
		}
		return null;
	}
	public float updateCost(int pId,float cost)
	{
		float iCost=0;
		float newCost = 0;
		Iterator<Product> itr=list.iterator();
		
		while(itr.hasNext())
		{
			
			product=itr.next();
			iCost=product.getCost();
			if(product.getId()==prdId)
			{
				product.setCost(cost);
				newCost=product.getCost();
			}
			
		}
		System.out.println("Initial Cost : "+iCost);
		return newCost;
		
	
	}

}
