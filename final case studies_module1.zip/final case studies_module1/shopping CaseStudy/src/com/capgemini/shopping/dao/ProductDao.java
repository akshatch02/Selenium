package com.capgemini.shopping.dao;

import java.util.List;

import com.capgemini.shopping.bean.Product;
import com.capgemini.shopping.exception.CustomExp;

public interface ProductDao {
	
	public abstract int addProduct(Product p) throws CustomExp;
	
	public List<Product> listAllProductRecords();
	
	public abstract Product getProductById(int pId);
	
	public abstract float updateCost(int pId,float cost);
}
