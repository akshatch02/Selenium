package com.capgemini.shopping.service;

import java.util.List;

import com.capgemini.shopping.bean.Product;
import com.capgemini.shopping.exception.CustomExp;

public interface ProductService {
	
	public abstract int addProducts(Product P) throws CustomExp;
	public List<Product> listAllProductRecords();
	public abstract Product getProductById(int pId);
	public abstract Product getModelName(int pId);
	public abstract float updateCost(int pId,float cost);

}
