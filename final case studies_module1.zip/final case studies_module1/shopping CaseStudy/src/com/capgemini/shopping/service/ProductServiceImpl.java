package com.capgemini.shopping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.shopping.bean.Product;
import com.capgemini.shopping.dao.ProductDao;
import com.capgemini.shopping.dao.ProductDaoImpl;
import com.capgemini.shopping.exception.CustomExp;

public class ProductServiceImpl implements ProductService {

	private ProductDao serviceDao;
	
	private ArrayList<Product> myList;
	
	
	public ProductServiceImpl() {
		serviceDao=new ProductDaoImpl();
	}

	@Override
	public int addProducts(Product p) throws CustomExp {
		acceptProductDetails(p);
		int prdId=serviceDao.addProduct(p);
		return prdId;
	}

	public void acceptProductDetails(Product p) {
	  Scanner sc=new Scanner(System.in);
	  while(true)
	  {
		  String str=p.getCompanyName();
		  if(validateName(str))
		  {
			  break;
		  }
		  else
		  {
			  System.err.println("Wrong company name!!\n please start with capital letters ");
			  System.out.println("Enter company name again eg. Company");
			  p.setCompanyName(sc.next());
		  }
	  }
	  while(true)
	  {
		  String str1=p.getModelName();
		  if(validateName(p.getModelName()))
		  {
			  break;
		  }
		  else
		  {
			  System.err.println("Wrong model name!! start with Capital letters");
			  System.out.println("Enter Model name again");
			  p.setModelName(sc.next());
		  }
	  }
	  
		
	}

	@Override
	public List<Product> listAllProductRecords() {
		
		return serviceDao.listAllProductRecords();
	}

	public boolean validateName(String pName)
	{
		String pattern="[A-Z][a-zA-Z]*";
		if(pName.matches(pattern))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public Product getProductById(int pId) {
		// TODO Auto-generated method stub
		Product product=serviceDao.getProductById(pId);
		return product;
	}
	@Override
	public Product getModelName(int pId) {
		// TODO Auto-generated method stub
		Product product=serviceDao.getProductById(pId);
		return product;
	}

	@Override
	public float updateCost(int pId, float cost) {
		// TODO Auto-generated method stub
		float newCost=serviceDao.updateCost(pId, cost);
		return newCost;
		
	}
}
