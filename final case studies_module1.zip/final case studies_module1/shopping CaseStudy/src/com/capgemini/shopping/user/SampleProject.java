package com.capgemini.shopping.user;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.shopping.bean.Product;
import com.capgemini.shopping.exception.CustomExp;
import com.capgemini.shopping.service.ProductService;
import com.capgemini.shopping.service.ProductServiceImpl;


public class SampleProject {

	public static void main(String[] args) throws CustomExp {
		
		PropertyConfigurator.configure("src\\log4j.properties");
		
		ProductService service;
		{
			service=new ProductServiceImpl();
		}
		List list;
		
		Scanner sc=new Scanner(System.in);
		String ans;
		int no;
		do
		{
			System.out.println("*****Dmart Product Services*****");
			System.out.println("1.Add product");
			System.out.println("2.Display all product details");
			System.out.println("3.Search Product");
			System.out.println("4.Update Cost");
			System.out.println("5.Exit");
			
			System.out.println("Please enter your choice");
			no=sc.nextInt();
			
			switch(no){
			
			case 1:
				System.out.println("Enter the company name ");
				String cName=sc.next();
				
				System.out.println("Enter the model name ");
				String mName=sc.next();
				
				System.out.println("Enter the cost ");
				float cost=sc.nextFloat(); 
				
				Product p=new Product(cName,mName,cost);
				int prdId=service.addProducts(p);
				System.out.println("Your product id :"+prdId);
				break;
				
			case 2:
				List<Product> prdList=service.listAllProductRecords();
				System.out.println(prdList);
				break;
			
			case 3:
				System.out.println("Enter Product id");
				int pId=sc.nextInt();
				Product product=service.getProductById(pId);
				if(product==null)
				{
					System.out.println("Product not available");
				}
				
				else
				{
					System.out.println("******Prdouct Details******");
					System.out.println("\t Product Id : "+product.getId());
					System.out.println("\t Company Name : "+product.getCompanyName());
					System.out.println("\t Model Name : "+product.getModelName());
					System.out.println("\t Product Cost : "+product.getCost());
					System.out.println("\t Date of order : "+product.getTransDate());
				}
				break;	
				
			case 4:
				System.out.println("Enter the product id");
				pId=sc.nextInt();
				System.out.println("Change the cost");
				float newcost=sc.nextFloat();
				float Cost=service.updateCost(pId, newcost);
				System.out.println("Updated cost : "+Cost);
			
			
			case 5:
				System.exit(0);
				break;
				
			default:
			System.out.println("some error in switch case");
			break;
				
				
			}
			
			System.out.println("Do you want to continue yes/no");
			ans=sc.next();
		}while(ans.equals("Yes")||ans.equals("y")||ans.equals("yes"));

	}

	}

