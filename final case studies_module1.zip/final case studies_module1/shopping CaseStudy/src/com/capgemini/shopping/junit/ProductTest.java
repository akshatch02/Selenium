package com.capgemini.shopping.junit;

import static org.junit.Assert.assertEquals;


import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.shopping.bean.Product;
import com.capgemini.shopping.dao.ProductDao;
import com.capgemini.shopping.dao.ProductDaoImpl;
import com.capgemini.shopping.exception.CustomExp;

public class ProductTest {

	
	private static ProductDao services;
	
	@BeforeClass
	public static void initialize() throws CustomExp
	{
		services=new ProductDaoImpl();
	}
	
	@Test(expected=CustomExp.class)
	public void TestExceptionAfterInsert() throws CustomExp{
	Product p1=new Product("Company","Model",50000.00f);
	int r=services.addProduct(null);
	//assertEquals(112, r);
	}
	/*@Test
	public void  GetId() throws CustomExp {
		ProductDao serviceDao=new ProductDaoImpl();
		Product p1=new Product("Samsung","Galaxy7",20000.00f);
		int prdId=serviceDao.addProduct(p1);
		assertEquals(10001, prdId);
	}
	/*@Test
	public void  GetCompanyName() {
		Product product=new Product(2000.00f);
		assertEquals("Capgemini", product.getCompanyName());
	}
	@Test
	public void  GetModelName() {
		Product product1=new Product();
		assertEquals("JEE Full Stack Developer", product1.getModelName());
	}
*/


}
