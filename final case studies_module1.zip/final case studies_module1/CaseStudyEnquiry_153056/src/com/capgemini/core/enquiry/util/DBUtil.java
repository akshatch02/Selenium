package com.capgemini.core.enquiry.util;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.enquiry.beans.Enquiry;

public class DBUtil {

	
		   
		private List<Enquiry> enquiry=new ArrayList<Enquiry>();

		public List<Enquiry> getEnquiry() 
		{
			return enquiry;
		}

		public void setEnquiry(List<Enquiry> enquiry)
        {
			this.enquiry = enquiry;
		}
		
		
		
	
}
