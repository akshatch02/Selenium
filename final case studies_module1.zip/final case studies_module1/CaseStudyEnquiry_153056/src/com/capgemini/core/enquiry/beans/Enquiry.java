package com.capgemini.core.enquiry.beans;

import java.util.Date;

public class Enquiry 
{
	    private int id;
	    private String fname;
		private String lname;
		private String gender;
		private String tech;
		
		
		

		public Enquiry(int id) {
			super();
			this.id = id;
		}

		
		

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + id;
			return result;
		}




		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Enquiry other = (Enquiry) obj;
			if (id != other.id)
				return false;
			return true;
		}




		public Enquiry() {
			super();
			
		}
		
		


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public String getFname() {
			return fname;
		}


		public void setFname(String fname) {
			this.fname = fname;
		}


		public String getLname() {
			return lname;
		}


		public void setLname(String lname) {
			this.lname = lname;
		}


		public String getGender() {
			return gender;
		}


		public void setGender(String gender) {
			this.gender = gender;
		}


		public String getTech() {
			return tech;
		}


		public void setTech(String tech) {
			this.tech = tech;
		}


		@Override
		public String toString() {
			return "Enquiry [id=" + id + ", fname=" + fname + ", lname=" + lname + ", gender=" + gender + ", tech="
					+ tech + "]";
		}
	
		
		
		
}
