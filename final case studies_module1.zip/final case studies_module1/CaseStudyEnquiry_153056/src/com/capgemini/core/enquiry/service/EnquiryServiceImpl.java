package com.capgemini.core.enquiry.service;


import com.capgemini.core.enquiry.beans.Enquiry;
import com.capgemini.core.enquiry.exception.EnquiryException;
import com.capgemini.core.enquiry.model.EnquiryDAO;
import com.capgemini.core.enquiry.model.EnquiryDAOImpl;

public class EnquiryServiceImpl implements EnquiryService 
{
		
	private EnquiryDAO enqDAO;

	public EnquiryServiceImpl()
	{
		
		enqDAO=new EnquiryDAOImpl();
	}

	@Override
	public int addEnquiry(Enquiry enquiry) throws EnquiryException {
		int enqId=0;
		if(isValid(enquiry))
		enqId=enqDAO.addEnquiry(enquiry);
		
		return enqId;

		

	}

	@Override
	public Enquiry getEnquiry(int id) throws EnquiryException
	{
		
		Enquiry enquiry=null;
		enquiry=enqDAO.getEnquiry(id);
		return enquiry;
		
	}
	
	@Override
	public boolean isValid(Enquiry enquiry) throws EnquiryException
	{

		//validation code
		return true;
	}
}