package com.capgemini.core.enquiry.model;

import java.util.List;

import com.capgemini.core.enquiry.beans.Enquiry;
import com.capgemini.core.enquiry.exception.EnquiryException;
import com.capgemini.core.enquiry.util.DBUtil;



public class EnquiryDAOImpl implements EnquiryDAO
{
	

        private List<Enquiry> enquiries;
		private DBUtil dbUtil=new DBUtil();
		

		//to remember previously assigned enquiry id
		private  int enquiryId=1000;
		
		public EnquiryDAOImpl()
		{
			enquiries=dbUtil.getEnquiry();
		}
		
		public int generateEnquiryId()
		{
			return ++enquiryId;
		}

		
		
		
		@Override
		public int addEnquiry(Enquiry enquiry) throws EnquiryException
		{

		    int enqId=generateEnquiryId();
			enquiry.setId(enqId);
			enquiries.add(enquiry);
			return enqId;
	    }
		
		
		
		@Override
		public Enquiry getEnquiry(int id) throws EnquiryException 
		{
			int index=enquiries.indexOf(new Enquiry(id));
			if(index== -1)//employee not found
			throw new EnquiryException("employee not found with id"+id);
			
			
			
			
			return enquiries.get(index);
		}

}
