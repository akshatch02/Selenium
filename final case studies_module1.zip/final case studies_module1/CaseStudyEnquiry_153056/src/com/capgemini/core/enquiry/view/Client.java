package com.capgemini.core.enquiry.view;

import java.util.Scanner;



import com.capgemini.core.enquiry.beans.Enquiry;
import com.capgemini.core.enquiry.exception.EnquiryException;
import com.capgemini.core.enquiry.service.EnquiryService;
import com.capgemini.core.enquiry.service.EnquiryServiceImpl;

public class Client
{
	
    //loose coupling due to the use of interface ref
	private EnquiryService enquiryService;
	
    public Client() 
	{
		//association-linking to service
		enquiryService=new EnquiryServiceImpl();
	}
    
    
    public void menu()
	{
		System.out.println("1) Add enquiry");
		System.out.println("2) Get enquiry");
		System.out.println("0) Exit Appliction");
		  
		Scanner console=new Scanner(System.in);
		
		System.out.println("\n please select an option:");
		int choice=console.nextInt();
    
		
		switch (choice)
		{
		case 1:
			Enquiry enquiry=new Enquiry();
			System.out.println("1) Enter first name:");
			String fname=console.next();
			System.out.println("2) enter last name:");
			String lname=console.next();
			
			System.out.println("3) enter gender:");
			String gender=console.next();
			
			System.out.println("4) enter technology interested");
			String tech=console.next();
			
			
            enquiry.setFname(fname);
		    enquiry.setLname(lname);
		    enquiry.setGender(gender);
		    enquiry.setTech(tech);
		    
		    try 
		    {
				int enqId=enquiryService.addEnquiry(enquiry);
				System.out.println("employee added successfully, Enquiry ID"+enqId);
			} 
		    catch (EnquiryException e) 
		    {
			
				e.printStackTrace();
			}
			catch (Exception e) 
		    {
				
				e.printStackTrace();
			}
		    
			break;
			

		case 2:
			System.out.println("enter enquiry id to view details");
			int id=console.nextInt();
			
			try {
			 enquiry=enquiryService.getEnquiry(id);
			 
			 System.out.println("ID "+enquiry.getId());
	       	 System.out.println("FirstName "+enquiry.getFname());
			 System.out.println("LastName "+enquiry.getLname());
			 System.out.println("Gender "+enquiry.getGender());
			 System.out.println("Technology "+enquiry.getTech());
			
		}catch(EnquiryException e1) {
			e1.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
			 
			
		}
			
			
		break;
		
		case 0:
			System.out.println("goodbye");
			System.exit(0);
        break;

       default:
	   System.out.println("invalid option");
	   break;
			
			
		}
	}
    
    
    public static void main(String[] args) {
		Client client=new Client();
		
		while(true)
		client.menu();
		
		
	
		
}
}		
			