package com.capgemini.core.ems.util;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.ems.beans.Employee;



public class DBUtill
{
   
	private List<Employee> employees=new ArrayList<Employee>();
	{
		
		employees.add(new Employee(101,"John", 23000,"IT",null,null));
		
	}
	
	
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
}
