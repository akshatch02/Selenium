package com.capgemini.core.ems.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.ems.beans.Employee;
import com.capgemini.core.ems.exceptions.EMSException;
import com.capgemini.core.ems.model.EmployeeDAO;
import com.capgemini.core.ems.model.EmployeeDAOImpl;
import com.capgemini.core.ems.service.EmployeeService;
import com.capgemini.core.ems.service.EmployeeServiceImpl;

public class Client {
	
	//loose coupling due to the use of interface ref
	private EmployeeService employeeService;
	

	
	public Client() {
		//association-linking to service
		employeeService=new EmployeeServiceImpl();
	}
	
	public void menu()
	{
		System.out.println("1) Add employee information");
		System.out.println("2) Get employee information");
		System.out.println("3) Update employee information");
		System.out.println("4) Remove employee information");
		System.out.println("5) View employee information");
		System.out.println("0) Exit Appliction");
		  
		Scanner console=new Scanner(System.in);
		
		System.out.println("\n please select an option:");
		int choice=console.nextInt();
		
		
		switch (choice)
		{
		case 1:
			Employee employee=new Employee();
			
			System.out.println("1) Enter employee name:");
			String name=console.next();
			System.out.println("2) enter employee salary:");
			double salary=console.nextDouble();
			
			System.out.println("3) enter employee department:");
			String department=console.next();
			
			System.out.println("4) enter employee date of birth(dd-MM-yyyy)");
			String dateOfBirthStr=console.next();
			
			System.out.println("5) enter employee date of joining");
			String dateOfJoining=console.next();
			
		
			
			employee.setName(name);
			employee.setSalary(salary);
			employee.setDepartment(department);
			employee.setDateOfBirth(convertToDate(dateOfBirthStr));
			employee.setDateOfJoining(convertToDate(dateOfJoining));
			
			
			try {
				int empId=employeeService.addEmployee(employee);
				System.out.println("employee added successfully, Employee ID"+empId);
			} catch (EMSException e) {
			
				e.printStackTrace();
			}
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
		
		break;
			
		case 2:
			System.out.println("enter employee id to view details");
			int id=console.nextInt();
			
			try {
			 employee=employeeService.getEmployee(id);
			 
			 System.out.println("ID"+employee.getId());
	       	 System.out.println("Name"+employee.getName());
			 System.out.println("salary"+employee.getSalary());
			 System.out.println("department"+employee.getDepartment());
			 System.out.println("date of birth"+employee.getDateOfBirth());
			 System.out.println("date of joining"+employee.getDateOfJoining());
		}catch(EMSException e1) {
			e1.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
			 
			
		}
			
			
		break;
			
		case 3:
			
			//get employee details if exists
			
			System.out.println("enter employee id to update Details");
		id=console.nextInt();
		try {
			 employee=employeeService.getEmployee(id);
			 
			 System.out.println("employee name is"+employee.getName());
			 System.out.println("do you want to update name?(yes/no)");
			 String reply=console.next();
			 
			 if(reply.equalsIgnoreCase("yes"))
			 {
				 System.out.println("enter new name");
				 employee.setName(console.next());
			 }
			 
			 
			 
			 
			 System.out.println("employee salary is"+employee.getSalary());
			 System.out.println("do you want to update salary?(yes/no)");
			  reply=console.next();
			 
			 if(reply.equalsIgnoreCase("yes"))
			 {
				 System.out.println("enter new salary");
				 employee.setSalary(console.nextDouble());
			 }
			 
			
			 
			 
			 System.out.println("employee department is"+employee.getDepartment());
			 System.out.println("do you want to update department?(yes/no)");
			 reply=console.next();
			 
			 if(reply.equalsIgnoreCase("yes"))
			 {
				 System.out.println("enter new department");
				 employee.setDepartment(console.next());
			 }
			 
			 
			 
			 
			 System.out.println("employee date of birth is"+employee.getDateOfBirth());
			 System.out.println("do you want to update date of birth?(yes/no)");
			  reply=console.next();
			 
			 if(reply.equalsIgnoreCase("yes"))
			 {
				 System.out.println("enter new date of birth");
				 employee.setDateOfBirth(convertToDate(console.next()));
			 }
			 
			 
			 
			 

			 System.out.println("employee date of joining is"+employee.getDateOfJoining());
			 System.out.println("do you want to update date of joining?(yes/no)");
			 reply=console.next();
			 
			 if(reply.equalsIgnoreCase("yes"))
			 {
				 System.out.println("enter new date of joining");
				 employee.setDateOfJoining(convertToDate(console.next()));
			 }
			 
			 
			 employeeService.updateEmployees(employee);
			 System.out.println("employee details updated successfully");
			 
			 
			 
		}catch(EMSException e1) {
			e1.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
			 
			
		}
		
	    break;
	    
	    
				
		case 4:
			System.out.println("enter id to delete employee details");
			id=console.nextInt();

			try {
			 employee=employeeService.removeEmployee(id);
			 
			 System.out.println("employee with below id is removed");
			 System.out.println("ID"+employee.getId());
	       	 System.out.println("Name"+employee.getName());
			 System.out.println("salary"+employee.getSalary());
			 System.out.println("department"+employee.getDepartment());
			 System.out.println("date of birth"+employee.getDateOfBirth());
			 System.out.println("date of joining"+employee.getDateOfJoining());
		}catch(EMSException e1) {
			e1.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
			 
			
		}
			
			
			
			
		break;
				
		case 5:
			try {
				List<Employee>employees=employeeService.getAllEmployees();
				
				Iterator<Employee> it =employees.iterator();
				System.out.println("ID \tName \tSalary \tDepartment \tDOB \tDOJ");
				
				while(it.hasNext())
				{
					Employee emp=it.next();
					System.out.println(emp.getId() + "\t" +
							           emp.getName() + "\t" +
					                   emp.getSalary() + "\t" +
					                   emp.getDepartment() + "\t" +
					                   emp.getDateOfBirth() + "\t" +
					                   emp.getDateOfJoining() + "\t" );
					                  
					
					
		         }
			     } catch (EMSException e)
			{
				
				e.printStackTrace();
			}
		break;
				
		case 0:
		System.out.println("Goodbye");
		System.exit(0);
		break;
		
		default:
			System.out.println("invalid option");
			break;
				
			
		}
	}
	
	public Date convertToDate(String dateInString)
	{
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date=LocalDate.parse(dateInString, formatter);
		java.util.Date dt=java.sql.Date.valueOf(date);
		return dt;
		
	}
	
	public static void main(String[] args) {
		Client client=new Client();
		
		while(true)
		client.menu();
		
	}
}
