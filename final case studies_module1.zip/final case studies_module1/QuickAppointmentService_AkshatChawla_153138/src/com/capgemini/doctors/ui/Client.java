package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client 
{
	private IDoctorAppointmentService appointmentService;

	public Client() 
	{
		appointmentService = new DoctorAppointmentService();
	}

	public void menu()
	{
		Scanner console = new Scanner( System.in );

		System.out.println("1) Book Doctor Appointment"); 
		System.out.println("2) View Doctor Appointment");
		System.out.println("3) Exit");

		System.out.print("\nEnter Your Choice: ");
		int choice = console.nextInt();
		
		switch( choice )
		{
		case 1:

			System.out.print("\n\nEnter Name of the Patient: ");
			String patientName = console.next();

			System.out.print("Enter Phone Number: ");
			String phoneNumber = console.next();

			System.out.print("Enter Email: ");
			String email = console.next();

			System.out.print("Enter Age: ");
			int age = console.nextInt();

			System.out.print("Enter Gender: ");
			String gender = console.next();

			System.out.print("Enter Problem name: ");
			String problemName = console.next();



			//Instantiating and initializing The Bean

			DoctorAppointment appointment = new DoctorAppointment();

			appointment.setPatientName( patientName );
			appointment.setPhoneNumber( phoneNumber );
			appointment.setEmail( email );
			appointment.setAge( age );
			appointment.setGender( gender );
			appointment.setProblemName( problemName );

			//sending appointment request to service

			try 
			{
				int appointmentId = appointmentService.addDoctorAppointmentDetails(appointment);
				
				System.out.println("\n\nYour Doctor Appointment has been successfully registered, your appointment ID is : "+ appointmentId  + "\n\n");
			
			}
			catch (DoctorAppointmentException e) 
			{
				System.out.println("Something went wrong. Reason: " + e.getMessage() );
			}
			catch(Exception e)
			{
				System.out.println("Something went wrong. Please try again after some time.");
			}
			break;
			
		case 2:
			System.out.print("\n\nEnter the appointment Id: ");
			int appointmentId = console.nextInt();
			
			try 
			{
				DoctorAppointment docappointment = appointmentService.getDoctorAppointmentDetails(appointmentId);
				
				System.out.println("\nPatient Name       : " + docappointment.getPatientName() );
				System.out.println("Appointment Status : " + docappointment.getAppointmentStatus() );
				
				if( docappointment.getAppointmentStatus().equalsIgnoreCase("DISAPPROVED") )
				{
					System.out.println("Doctor Name         : ");
				}
				else
				{
					System.out.println("Doctor Name         : " + docappointment.getDoctorName() );
					
					System.out.println("\n\nAppointment time, along with doctor�s phone number will be shared shortly with you.");
				}
				
			} 
			catch (DoctorAppointmentException e) 
			{
				System.out.println("Something went wrong. Reason: " + e.getMessage() );
			}
			catch(Exception e)
			{
				System.out.println("Something went wrong. Please try again after some time.");
			}
			break;
			
		case 3:
			System.out.println("Thank you for using out Quick Appointment Service Application");
			System.exit( 0 );
			break;
			
		}

	}
	
		public static void main(String[] args) 
		{
		Client client=new Client();
				
		while(true)
		client.menu();
		}

}
