package com.capgemini.doctors.dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorAppointmentException;

public class DoctorAppointmentDao implements IDoctorAppointmentDao 
{
	private List<DoctorAppointment> appointments = new ArrayList<DoctorAppointment>();
	private Map<String, String> doctorSpeciality = new HashMap<String, String>();
	
	{
	doctorSpeciality.put("Heart", "Dr. Brijesh Kumar");
	doctorSpeciality.put("Gynecology", "Dr. Sharda Singh");
	doctorSpeciality.put("Diabetes", "Dr. Heena Khan");
	doctorSpeciality.put("ENT", "Dr. Paras Mal");
	doctorSpeciality.put("Bone", "Dr. Renuka Kher");
	doctorSpeciality.put("Dermatology", "Dr. Kanika Kapoor");
	}
	
	public int generateAppointmentRand()
	{
		double rndDouble=Math.random();
		
		return (int)(rndDouble*10000);
	}
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorAppointmentException 
	{
		doctorAppointment.setAppointmentId( generateAppointmentRand() );
		
		String problem= doctorAppointment.getProblemName();
		
		if( doctorSpeciality.get(problem) != null )
		{
			
			
			doctorAppointment.setAppointmentStatus("Approved");
			doctorAppointment.setDoctorName( doctorSpeciality.get(problem) );
		}
		
		//add appointment request irrespective of approval status
		appointments.add( doctorAppointment );
		
		return doctorAppointment.getAppointmentId();

	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DoctorAppointmentException 
	{
		DoctorAppointment appointment = null;
		
		int index = appointments.indexOf( new DoctorAppointment( appointmentId ) );
		
		//check if appointment request exists
		if( index == -1 )
		{
			
			throw new DoctorAppointmentException("Sorry No Appointment Request exists with id " + appointmentId);
		}
		
		//else get the appointment which exists
		appointment = appointments.get( index ); 
		
		return appointment;
		
		
	}

}
