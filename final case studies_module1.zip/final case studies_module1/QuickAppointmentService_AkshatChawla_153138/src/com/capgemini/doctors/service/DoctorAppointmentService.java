package com.capgemini.doctors.service;


import java.util.Date;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.DoctorAppointmentException;

public class DoctorAppointmentService implements IDoctorAppointmentService 
{
	private IDoctorAppointmentDao appointmentDAO;

	public DoctorAppointmentService() 
	{
		appointmentDAO = new DoctorAppointmentDao();
	} 

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorAppointmentException 
	{
		int appointmentId = 0;
		
		if(isValid(doctorAppointment)==true);
		appointmentId = appointmentDAO.addDoctorAppointmentDetails(doctorAppointment);
			
		return appointmentId;
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DoctorAppointmentException 
	{
		return appointmentDAO.getDoctorAppointmentDetails(appointmentId);
	}
	
	
	public boolean isValid(DoctorAppointment appointment) throws DoctorAppointmentException 
	{
		if( appointment == null)
			throw new DoctorAppointmentException( "Appointment instance cannot be null" );
		
		if( appointment.getPatientName() == null || appointment.getPatientName().trim().isEmpty() )
			throw new DoctorAppointmentException( "Patient Name Cannot be Empty" );
		
		if( appointment.getPhoneNumber() == null ||  isPhoneNumberInvalid( appointment.getPhoneNumber() ) )
			throw new DoctorAppointmentException( "Phone Number is invalid" );
		
		if( appointment.getEmail() == null || isEmailInvalid( appointment.getEmail() ) )
			throw new DoctorAppointmentException( "Email has to be a valid email" );
		
		if( !(appointment.getAge() > 1 && appointment.getAge() <= 120) )
			throw new DoctorAppointmentException( "Age has to be between 1 to 120" );
		
		if( appointment.getGender() == null || isGenderInvalid( appointment.getGender() ) ) 
			throw new DoctorAppointmentException( "Gender can only be Male or Female" );
		
		if( appointment.getProblemName() == null ||  appointment.getProblemName().trim().isEmpty() )
			throw new DoctorAppointmentException( "Problem cannot be blank" );
		
		
		return true;
	}
	

	public static boolean isGenderInvalid(String gender) 
	{
		gender = gender.toLowerCase();
		
		if( !gender.matches("^male$|^female$"))
			return true;	
		else
			return false;
	}
	
	public boolean isEmailInvalid( String email ) {
		
		if( email.matches(".+\\@.+\\..+") ) 
		{
			return false;
		}		
		else 
			return true;
	}

	public static boolean isPhoneNumberInvalid( String phoneNumber )
	{
		if(phoneNumber.matches("[1-9][0-9]{9}")) 
		{
			return false;
		}		
		else 
			return true;
	}

}
