package com.capgemini.doctors.exception;

public class DoctorAppointmentException extends Exception
{

	public DoctorAppointmentException() 
	{
		super();
		
	}

	public DoctorAppointmentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public DoctorAppointmentException(String message, Throwable cause) 
	{
		super(message, cause);
		
	}

	public DoctorAppointmentException(String message) 
	{
		super(message);
		
	}

	public DoctorAppointmentException(Throwable cause) 
	{
		super(cause);
		
	}

}
