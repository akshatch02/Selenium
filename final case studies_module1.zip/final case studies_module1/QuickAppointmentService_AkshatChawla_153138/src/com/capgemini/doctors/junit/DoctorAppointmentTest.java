package com.capgemini.doctors.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.DoctorAppointmentException;

public class DoctorAppointmentTest 
{
	private static IDoctorAppointmentDao appointmentDAO;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		appointmentDAO=new DoctorAppointmentDao();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws DoctorAppointmentException 
	{
		DoctorAppointment appointment = new DoctorAppointment();
		
		appointment.setPatientName("Eric");
		appointment.setPhoneNumber("9898989898");
		appointment.setEmail("eric@gmail.com");
		appointment.setGender("Male");
		appointment.setAge(32);
		appointment.setProblemName("Heart");
		
		
		int appointmentRequestId = appointmentDAO.addDoctorAppointmentDetails(appointment);
		
		assertTrue( appointmentRequestId > 0 );
		
	}
	
	@Test
	public void testGetAppointmentStatus1() throws DoctorAppointmentException 
	{
	DoctorAppointment appointment = new DoctorAppointment();
		
		appointment.setPatientName("Eric");
		appointment.setPhoneNumber("9898989898");
		appointment.setEmail("eric@gmail.com");
		appointment.setGender("Male");
		appointment.setAge(32);
		appointment.setProblemName("Heart");
		
		
		int appointmentRequestId = appointmentDAO.addDoctorAppointmentDetails(appointment);
		
		DoctorAppointment appointment2= appointmentDAO.getDoctorAppointmentDetails(appointmentRequestId);
		
		assertNotEquals(null, appointment2);
	}

}
