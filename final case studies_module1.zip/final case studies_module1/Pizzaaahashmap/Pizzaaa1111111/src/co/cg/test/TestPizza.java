package co.cg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.core.pizza.Exception.PizzaException;
import com.capgemini.core.pizza.beans.Customer;
import com.capgemini.core.pizza.beans.PizzaOrder;
import com.capgemini.core.pizza.service.PizzaService;
import com.capgemini.core.pizza.service.PizzaServiceImpl;

public class TestPizza {

	static PizzaService pizzaservice;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		pizzaservice=new PizzaServiceImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws PizzaException {
Customer cust=new Customer();
PizzaOrder order=new PizzaOrder();
		
		cust.setCustName("bhagyashri");
		cust.setAddress("as");
		cust.setPhone(7206333344l);
		order.setToppings("Paner");
		
		int reqId=pizzaservice.placeOrder(cust, order);
		
		assertTrue(reqId>0);
	}
	
	@Test
	public void test2() throws PizzaException {
Customer cust=new Customer();
PizzaOrder order=new PizzaOrder();
		
		cust.setCustName("bhagyashri");
		cust.setAddress("as");
		cust.setPhone(7206333344l);
		order.setToppings("Paneer");
		
		int reqId=pizzaservice.placeOrder(cust, order);
		
		PizzaOrder pizza=pizzaservice.getOrderDetails(reqId);
		
		assertNotEquals(null, pizza);

}
}
