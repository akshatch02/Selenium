package com.capgemini.core.pizza.model;

import com.capgemini.core.pizza.Exception.PizzaException;
import com.capgemini.core.pizza.beans.Customer;
import com.capgemini.core.pizza.beans.PizzaOrder;


public interface PizzaDAO
{
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException;
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
}
