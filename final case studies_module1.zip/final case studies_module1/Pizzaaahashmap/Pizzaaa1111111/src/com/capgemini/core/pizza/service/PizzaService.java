package com.capgemini.core.pizza.service;

import com.capgemini.core.pizza.Exception.PizzaException;
import com.capgemini.core.pizza.beans.Customer;
import com.capgemini.core.pizza.beans.PizzaOrder;

public interface PizzaService
{
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException;
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException;
}
