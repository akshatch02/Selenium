package com.capgemini.core.pizza.beans;

import java.time.LocalDateTime;
import java.util.Date;

public class PizzaOrder 
{
	private int orderId;
	private int customerId;
	private double totalPrice;
	private String toppings;
	private Date  orderDate;
	
	
	public PizzaOrder() {
		super();
	}
	

	public PizzaOrder(int orderId) {
		super();
		this.orderId = orderId;
	}


	public PizzaOrder(int orderId, int customerId, double totalPrice,
			String toppings, Date orderDate) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
		this.toppings = toppings;
		this.orderDate = orderDate;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getToppings() {
		return toppings;
	}

	public void setToppings(String toppings) {
		this.toppings = toppings;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId
				+ ", totalPrice=" + totalPrice + ", toppings=" + toppings
				+ ", orderDate=" + orderDate + "]";
	}
	
}