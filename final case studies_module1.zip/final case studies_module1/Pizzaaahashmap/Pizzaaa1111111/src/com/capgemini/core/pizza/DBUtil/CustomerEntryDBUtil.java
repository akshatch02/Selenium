package com.capgemini.core.pizza.DBUtil;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.core.pizza.beans.Customer;
import com.capgemini.core.pizza.beans.PizzaOrder;

public class CustomerEntryDBUtil
{
	Map<Integer,PizzaOrder> pizzadetails=new HashMap<Integer, PizzaOrder>();
	{
		
	}
	
	
	public Map<Integer, PizzaOrder> getPizzadetails() {
		return pizzadetails;
	}
	public void setPizzadetails(Map<Integer, PizzaOrder> pizzadetails) {
		this.pizzadetails = pizzadetails;
	}
	
	
	
}
