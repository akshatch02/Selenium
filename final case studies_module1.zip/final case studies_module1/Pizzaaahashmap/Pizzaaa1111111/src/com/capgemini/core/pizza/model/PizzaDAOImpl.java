package com.capgemini.core.pizza.model;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.core.pizza.DBUtil.CustomerEntryDBUtil;
import com.capgemini.core.pizza.DBUtil.PizzaEntryDBUtil;
import com.capgemini.core.pizza.Exception.PizzaException;
import com.capgemini.core.pizza.beans.Customer;
import com.capgemini.core.pizza.beans.PizzaOrder;

public class PizzaDAOImpl implements PizzaDAO
{
	Map<String,Integer> pizzaEntry=new HashMap<>();
	Map<Integer,PizzaOrder> customerEntry=new HashMap<>();

    PizzaEntryDBUtil dbUtil=new PizzaEntryDBUtil();
    CustomerEntryDBUtil cdbUtil=new CustomerEntryDBUtil();
    
    int basePrice=350;
    
	public PizzaDAOImpl()  
	{
		pizzaEntry=dbUtil.getPizzaorder();
		customerEntry=cdbUtil.getPizzadetails();
	}
	
	//returns any value between 1 to 10000
	public int generatcustomerRand()
	{
		double rndDouble=Math.random();
		
		return (int)(rndDouble*10000);
	}
	public int generatorderRand()
	{
		double rndDouble=Math.random();
		
		return (int)(rndDouble*10000);
	}

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)throws PizzaException 
	{

			int orderId=generatorderRand();
			
			pizza.setOrderId(orderId);
			
			int custId=generatcustomerRand();
			
			pizza.setCustomerId(custId);
			
			String toppings=pizza.getToppings();
			
			if(pizzaEntry.containsKey(toppings))
			{
				int price=pizzaEntry.get(toppings);
			
				int totalprice=basePrice+price;
				
				pizza.setTotalPrice(totalprice);
				
				//adding to map pizzaEntry
				customerEntry.put(orderId, pizza);
				
		
				
				System.out.println("Your order is approved having request Id: "+orderId +"and totalprice for your order is "+totalprice);
			}
			
			else
			{
				System.out.println("Topping you are looking for is not avilable");	
		}
			return orderId;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		 PizzaOrder pizzz=customerEntry.get(orderid);
			
			if(pizzz==null)
				throw new PizzaException("order not found with id" +orderid);
			
			return pizzz;
	}
	


}

