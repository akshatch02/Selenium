package com.capgemini.core.pizza.DBUtil;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.core.pizza.beans.PizzaOrder;



public class PizzaEntryDBUtil
{
	Map<String,Integer> pizzaorder=new HashMap<String, Integer>();
	{
		pizzaorder.put("Capsicum", 30);
		pizzaorder.put("Mushroom", 50);
		pizzaorder.put("Paneer", 70);
	
	}
	public Map<String, Integer> getPizzaorder() {
		return pizzaorder;
	}
	public void setPizzaorder(Map<String, Integer> pizzaorder) {
		this.pizzaorder = pizzaorder;
	}
	
	
	
}
