package com.capgemini.core.pizza.service;

import com.capgemini.core.pizza.Exception.PizzaException;
import com.capgemini.core.pizza.beans.Customer;
import com.capgemini.core.pizza.beans.PizzaOrder;
import com.capgemini.core.pizza.model.PizzaDAO;
import com.capgemini.core.pizza.model.PizzaDAOImpl;

public class PizzaServiceImpl implements PizzaService
{
	private PizzaDAO pizzaDao;
	
	public PizzaServiceImpl() 

	{
		pizzaDao=new PizzaDAOImpl();
	}
	
	
	
	
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)throws PizzaException 
	{
		int orderId=0;
	
      orderId=pizzaDao.placeOrder(customer, pizza);
	
	  return orderId;
		
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException
	{
	PizzaOrder pizord=null;
		pizord=pizzaDao.getOrderDetails(orderid);
		return pizord;
	}
	

}
