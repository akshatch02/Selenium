package com.capgemini.core.pizza.view;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;

import com.capgemini.core.pizza.Exception.PizzaException;
import com.capgemini.core.pizza.beans.Customer;
import com.capgemini.core.pizza.beans.PizzaOrder;
import com.capgemini.core.pizza.service.PizzaService;
import com.capgemini.core.pizza.service.PizzaServiceImpl;



public class Client 
{
	private PizzaService pizser;

	public Client() 
	{
		pizser=new PizzaServiceImpl();
		
	}
	
	public void menu()
	{
		System.out.println("1) Place Order");
		System.out.println("2) Get order Details");
		System.out.println("0) Exit Application");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please select an option: ");
		int choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:
			
			Customer cusDetails=new Customer();
			PizzaOrder pizza =new PizzaOrder();
			
			System.out.println(" Enter customer name: ");
			String name=sc.next();
			
			System.out.println(" Enter customer address: ");
			String add=sc.next();
			
			System.out.println(" Enter phonenumber: ");
			long phnno=sc.nextLong();
			
			System.out.println("Enter extra topping you want to add: ");
			System.out.println("1) Paneer-70");
			System.out.println("1) Capsicum-30");
			System.out.println("1) Mushroom-50");
			String topping=sc.next();
		
			cusDetails.setCustName(name);
			cusDetails.setAddress(add);
			cusDetails.setPhone(phnno);
			pizza.setToppings(topping);
			
			try {
				int orderId=pizser.placeOrder(cusDetails,pizza);	
			} 
			catch (PizzaException e) 
			{
				
				e.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
				
			}
			break;
			
case 2:
			
			System.out.println("Enter order ID to view details: ");
			int ordrId=sc.nextInt();
			
			try 
			{
				pizza=pizser.getOrderDetails(ordrId);
				
				System.out.println("customer Id: "+pizza.getCustomerId());
				System.out.println("order id: "+pizza.getOrderId());
				System.out.println("total price: "+pizza.getTotalPrice());
			
			} 
			catch (PizzaException e) 
			{
				
				e.printStackTrace();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				
			}
			break;
			

case 0:
	System.out.println("GoodBye");
	System.exit(0);
	break;	
}	
}
	
	public Date convertToDate(String dateInString)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate localdate=LocalDate.parse(dateInString,formatter);
		java.util.Date date=java.sql.Date.valueOf(localdate);
		return date;
	}
	
	public static void main(String[] args) {
		
		Client client=new Client();	
		while(true)
		client.menu();
}
}