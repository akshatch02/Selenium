package com.capgemini.core.service;

import com.capgemini.core.beans.Doctor;
import com.capgemini.core.exception.DoctorsException;

import com.capgemini.core.model.DoctorDAO;
import com.capgemini.core.model.DoctorDAOImpl;

public class DoctorServiceImpl implements DoctorService
{
	public DoctorDAO docDAO;
	
	public  DoctorServiceImpl()
	
	{
		docDAO=new DoctorDAOImpl();
	}
		
	     
			@Override
			public int addPatientDetails(Doctor doc) throws DoctorsException 
			{
				int appId=0;   		
		   		appId=docDAO.addPatientDetails(doc);
		   		return appId;
			}
		
		       @Override
				public Doctor getAppointmentDetails(int appId) throws DoctorsException 
				{
		    	   Doctor doctor=null;
		    	doctor=docDAO.getAppointmentDetails(appId);
		    	return doctor;
				}
				
		       
		       
		}
	
	
	

