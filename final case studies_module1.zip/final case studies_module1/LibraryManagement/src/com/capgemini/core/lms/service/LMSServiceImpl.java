package com.capgemini.core.lms.service;

import java.util.Collection;
import java.util.List;


import com.capgemini.core.lms.beans.Book;
import com.capgemini.core.lms.exception.LMSException;
import com.capgemini.core.lms.model.LMSDAO;
import com.capgemini.core.lms.model.LMSDAOImpl;

public class LMSServiceImpl implements LMSService
{
	private LMSDAO lmsDAO;
	
	public LMSServiceImpl()
	{
		//association-(link)
		lmsDAO=new LMSDAOImpl();
	}
	
	
	
	
	
	

	@Override
	public int addBook(Book book) throws LMSException {

		int bookId=0;
		
		//if(isValid(book))
		
			bookId=lmsDAO.addBook(book);
		return bookId;
		
	}

	
	
	
	
	@Override
	public Book getBook(int bookId) throws LMSException {
	

		Book bookk=null;
		
		bookk=lmsDAO.getBook(bookId);
		return bookk;
	}

	@Override
	public void updateBook(Book book) throws LMSException {
		lmsDAO.updateBook(book);
		
	}

	@Override
	public Book removeBook(int bbokId) throws LMSException {
		Book bookkk=null;
		bookkk=lmsDAO.removeBook(bbokId);
		
		return bookkk;
	}

	@Override
	public Collection<Book> getAllBooks() throws LMSException {
		
		Collection<Book> bookkkk=null;
		bookkkk=lmsDAO.getAllBooks();
		return bookkkk;
	
	}
}
