package com.capgemini.core.lms.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.core.lms.beans.Book;

public class LMSDBUtil {
	
	Map<Integer,Book> books=new HashMap<Integer, Book>();
	{
		books.put(101, new Book(101, "kjhk", "hyikjh", 1));
	}
	public Map<Integer, Book> getBooks() {
		return books;
	}
	public void setBooks(Map<Integer, Book> books) {
		this.books = books;
	}
	
	

}
