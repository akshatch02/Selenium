package com.capgemini.core.lms.model;

import java.util.Collection;
import java.util.List;

import com.capgemini.core.lms.beans.Book;
import com.capgemini.core.lms.exception.LMSException;

public interface LMSDAO 
{
	public int addBook(Book book) throws LMSException;
	
	public Book getBook(int bookId) throws LMSException;
	
	public void updateBook(Book book) throws LMSException;
	
	public Book removeBook(int bbokId) throws LMSException;
	
	public Collection<Book> getAllBooks() throws LMSException;

}
