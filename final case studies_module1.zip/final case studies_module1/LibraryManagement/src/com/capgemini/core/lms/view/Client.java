package com.capgemini.core.lms.view;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.lms.beans.Book;
import com.capgemini.core.lms.exception.LMSException;
import com.capgemini.core.lms.model.LMSDAO;
import com.capgemini.core.lms.model.LMSDAOImpl;
import com.capgemini.core.lms.service.LMSService;
import com.capgemini.core.lms.service.LMSServiceImpl;

public class Client 
{
private LMSService lmsService;
	
	public Client()
	{
		//association-linking to service
		lmsService=new LMSServiceImpl();
	}
	
	public void menu()
	{
		System.out.println("1) Add Book Information");
		System.out.println("2) Get Book Information");
		System.out.println("3) Update Book Information");
		System.out.println("4) Remove book Information");
		System.out.println("5) View All book Information");
		System.out.println("0) Exit Application");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please select an option: ");
		int choice=sc.nextInt();
		
		
		switch(choice)
		{
		case 1:
			
			Book book=new Book();
			
			System.out.println("1) Enter book tile: ");
			String title=sc.next();
			
			System.out.println("2) Enter book author: ");
			String author=sc.next();
			
			System.out.println("3) Enter book price: ");
			float price=sc.nextFloat();
			
			
			book.setTitle(title);
			book.setAuthor(author);
			book.setPrice(price);
			
			try
			{
			int bookId = lmsService.addBook(book);
			
			System.out.println("book added successfully,book ID: "+bookId);
			}
			catch(LMSException e)
			{
				e.getMessage();
			}
			catch (Exception e) {
				e.getMessage();
				
			}
			break;
			
			
		case 2:
			
			System.out.println("Enter book ID to view details: ");
			int bookId=sc.nextInt();
			
			try {
				book = lmsService.getBook(bookId);
				
				System.out.println("Id: "+ book.getId());
				System.out.println("title: "+ book.getTitle());
				System.out.println("author: "+ book.getAuthor());
				System.out.println("price: "+ book.getPrice());
			} 
			catch (LMSException e1) 
			{
				
				e1.getMessage();
			}
			catch (Exception e1) 
			{
				
				e1.getMessage();
			}
			break;
			
			
			
			
		case 3:
			//get employee details if exists
			
			System.out.println("Enter book ID to update details: ");
			bookId=sc.nextInt();
			
			try {
				book = lmsService.getBook(bookId);
				
				//updating name
				System.out.println("Book Title: "+ book.getTitle());
				System.out.println("Do you want to update the title? (Yes/No");
				String reply=sc.next();
				
				if(reply.equalsIgnoreCase("Yes"))
				{
					System.out.println("Enter new title: ");
					book.setTitle(sc.next());
				}
				
				//updating salary
				System.out.println("Book Author: "+ book.getAuthor());
				System.out.println("Do you want to update the author? (Yes/No");
				reply=sc.next();
				
				if(reply.equalsIgnoreCase("Yes"))
				{
					System.out.println("Enter new author name: ");
					book.setAuthor(sc.next());
				}
				
				
				//updating Department
				System.out.println("Book price: "+ book.getPrice());
				System.out.println("Do you want to update the Price? (Yes/No");
				reply=sc.next();
				
				if(reply.equalsIgnoreCase("Yes"))
				{
					System.out.println("Enter new price: ");
					book.setPrice(sc.nextFloat());
				}
				
				
				lmsService.updateBook(book);
				System.out.println("BOOK details updated successfully");
				
			} 
			catch (LMSException e1) 
			{
				
				e1.printStackTrace();
			}
			catch (Exception e1) 
			{
				
				e1.printStackTrace();
			}
			break;
			
			
		case 4:
			System.out.println("Enter BOOK ID to Delete details: ");
			bookId=sc.nextInt();
			
			try {
				book = lmsService.removeBook(bookId);
				
				System.out.println("Book with below details removed:");
				System.out.println("Book Id: "+ book.getId());
				System.out.println("Title: "+ book.getTitle());
				System.out.println("Author: "+ book.getAuthor());
				System.out.println("Price: "+ book.getPrice());
				
			} 
			catch (LMSException e1) 
			{
				
				e1.printStackTrace();
			}
			catch (Exception e1) 
			{
				
				e1.printStackTrace();
			}
			break;
				
			
case 5:
			
			try
			{
				Collection<Book> books=lmsService.getAllBooks();
				Iterator<Book> it=books.iterator();
				
				System.out.println("ID \tAuthor \title \tprice ");
				while(it.hasNext())
				{
					Book buk=it.next();
					System.out.println(buk.getId() + "\t" +
									   buk.getTitle() + "\t" +
									   buk.getAuthor() + "\t" +
									   buk.getPrice() + "\t" );
									  
				}
			}
			catch(LMSException e)
			{
				e.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
				
			}
			break;
			
		case 0:
			System.out.println("GoodBye");
			System.exit(0);
			break;
			
		default:
			System.out.println("Invalid Option");
			break;
		}
				
				

}
public static void main(String[] args) {
	PropertyConfigurator.configure("log4j.properties");
		Client client=new Client();
		
		while(true)
			client.menu();
	}
		
		
	}		
