package com.capgemini.core.doctor.service;

import com.capgemini.core.doctor.bean.AppointmentDetails;
import com.capgemini.core.doctor.exception.AppointmentException;

public interface AppointmentService 
{
	public int addAppointment(AppointmentDetails details) throws AppointmentException;
	
	public AppointmentDetails getAppointmentDetails(int id) throws AppointmentException;


}
