package com.capgemini.core.doctor.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.capgemini.core.doctor.bean.AppointmentDetails;
import com.capgemini.core.doctor.exception.AppointmentException;
import com.capgemini.core.doctor.model.AppointmentDAO;
import com.capgemini.core.doctor.model.AppointmentDAOImpl;
import com.capgemini.core.doctor.view.Client;

public class AppointmentServiceImpl implements AppointmentService
{
	private AppointmentDAO appointmentDao;
	
	public AppointmentServiceImpl() 
	{
		appointmentDao=new AppointmentDAOImpl();
	}

	@Override
	public int addAppointment(AppointmentDetails details) throws AppointmentException 
	{
		int appId=0;
		
		if(isValid(details)==true);
		appId=appointmentDao.addAppointment(details);
		
		return appId;
	}

	@Override
	public AppointmentDetails getAppointmentDetails(int id) throws AppointmentException {
		AppointmentDetails appdetails=null;
		appdetails=appointmentDao.getAppointmentDetails(id);
		return appdetails;
	}
	
	
	
	public Date convertToDate(String dateInString)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate localdate=LocalDate.parse(dateInString,formatter);
		java.util.Date date=java.sql.Date.valueOf(localdate);
		return date;
	}
	
	
	public boolean isValid(AppointmentDetails appointment) throws AppointmentException 
	{
		if( appointment == null)
			throw new AppointmentException( "Appointment instance cannot be null" );
		
		if( appointment.getName() == null || appointment.getName().trim().isEmpty() )
			throw new AppointmentException( "Patient Name Cannot be Empty" );
		
		if( appointment.getPhoneNo() == 0 ||  isPhoneNumberInvalid( appointment.getPhoneNo() ) )
			throw new AppointmentException( "Phone Number is invalid" );
		
		if( appointment.getEmailId() == null || isEmailInvalid( appointment.getEmailId() ) )
			throw new AppointmentException( "Email has to be a valid email" );
		
//		if( !(appointment.getAge() > 1 && appointment.getAge() <= 120) )
//			throw new AppointmentException( "Age has to be between 1 to 120" );
		
		if( appointment.getGender() == null || isGenderInvalid( appointment.getGender() ) ) 
			throw new AppointmentException( "Gender can only be Male or Female" );
		
		if( appointment.getProblemName() == null ||  appointment.getProblemName().trim().isEmpty() )
			throw new AppointmentException( "Problem cannot be blank" );
		
		if( appointment.getDate() == null ||  isDateInvalid( appointment.getDate() ) )
			throw new AppointmentException( "AppointmentRequest date has to be greater then current date" );
		
		return true;
	}
	
	public boolean isDateInvalid(Date date) 
	{
		if( date.compareTo( new Date() ) <= 0)
			return true;
		else
			return false;
	}

	public static boolean isGenderInvalid(String gender) 
	{
		gender = gender.toLowerCase();
		
		if( !gender.matches("^male$|^female$"))
			return true;	
		else
			return false;
	}
	
	public boolean isEmailInvalid( String email ) {
		
		if( email.matches(".+\\@.+\\..+") ) 
		{
			return false;
		}		
		else 
			return true;
	}

	public static boolean isPhoneNumberInvalid( long phoneNumber )
	{
		if(String.valueOf(phoneNumber).matches("[1-9][0-9]{9}")) 
		{
			return false;
		}		
		else 
			return true;
	}
	
	public Date getDateFromString( String dateInString )
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		LocalDate localDate = LocalDate.parse(dateInString , formatter);

		java.util.Date date = java.sql.Date.valueOf( localDate );

		return date;
	}
	


}
