package com.capgemini.core.doctor.bean;

import java.util.Date;

public class AppointmentDetails 
{
	private int AppointmentId;
	private String Name;
	private long PhoneNo;
	private String EmailId;
	private int Age;
	private String Gender;
	private String ProblemName;
	private Date date;
	private String DocName;
	private String AppointmentStatus;
	
	public AppointmentDetails() {
		super();
	}
	
	

	public AppointmentDetails(int appointmentId) {
		super();
		AppointmentId = appointmentId;
	}



	public AppointmentDetails(int appointmentId, String name, long phoneNo, String emailId, int age, String gender,
			String problemName, Date date, String appointmentStatus) {
		super();
		AppointmentId = appointmentId;
		Name = name;
		PhoneNo = phoneNo;
		EmailId = emailId;
		Age = age;
		Gender = gender;
		ProblemName = problemName;
		this.date = date;
		AppointmentStatus = appointmentStatus;
	}

	public AppointmentDetails(int appointmentId, String name, long phoneNo, String emailId, int age, String gender,
			String problemName, Date date) {
		super();
		AppointmentId = appointmentId;
		Name = name;
		PhoneNo = phoneNo;
		EmailId = emailId;
		Age = age;
		Gender = gender;
		ProblemName = problemName;
		this.date = date;
	}

	public int getAppointmentId() {
		return AppointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		AppointmentId = appointmentId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public long getPhoneNo() {
		return PhoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		PhoneNo = phoneNo;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getProblemName() {
		return ProblemName;
	}

	public void setProblemName(String problemName) {
		ProblemName = problemName;
	}

	public String getDocName() {
		return DocName;
	}

	public void setDocName(String docName) {
		DocName = docName;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getAppointmentStatus() {
		return AppointmentStatus;
	}

	public void setAppointmentStatus(String appointmentStatus) {
		AppointmentStatus = appointmentStatus;
	}

	@Override
	public String toString() {
		return "AppointmentDetails [AppointmentId=" + AppointmentId + ", Name=" + Name + ", PhoneNo=" + PhoneNo
				+ ", EmailId=" + EmailId + ", Age=" + Age + ", Gender=" + Gender + ", ProblemName=" + ProblemName
				+ ", date=" + date + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + AppointmentId;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AppointmentDetails other = (AppointmentDetails) obj;
		if (AppointmentId != other.AppointmentId)
			return false;
		return true;
	}

	
	
	

}
