package com.capgemini.core.doctor.junit;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.core.doctor.bean.AppointmentDetails;
import com.capgemini.core.doctor.exception.AppointmentException;
import com.capgemini.core.doctor.service.AppointmentService;
import com.capgemini.core.doctor.service.AppointmentServiceImpl;

public class AppointmentTest 
{
	static AppointmentService appointmentService;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		appointmentService=new AppointmentServiceImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	public Date convertToDate(String dateInString)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate localdate=LocalDate.parse(dateInString,formatter);
		java.util.Date date=java.sql.Date.valueOf(localdate);
		return date;
	}
	
	@Test
	public void test() throws AppointmentException 
	{
		AppointmentDetails appointment=new AppointmentDetails();
		
		appointment.setName("Bhagyashri");
		appointment.setPhoneNo(7206333344L);
		appointment.setEmailId("bhagyashri@gmail.com");
		appointment.setGender("female");
		appointment.setProblemName("heart");
		appointment.setDate(convertToDate("04-12-2018"));
		
		int reqId=appointmentService.addAppointment(appointment);
		
		assertTrue(reqId>0);
		
	}
	
	@Test
	public void testGetAppointmentStatus1() throws AppointmentException 
	{
	AppointmentDetails appointment = new AppointmentDetails();
		
	appointment.setName("Bhagyashri");
	appointment.setPhoneNo(7206333344L);
	appointment.setEmailId("bhagyashri@gmail.com");
	appointment.setGender("female");
	appointment.setProblemName("heart");
	appointment.setDate(convertToDate("04-12-2018"));
		
		
		int appointmentRequestId = appointmentService.addAppointment( appointment );
		
		AppointmentDetails appointment2
		= appointmentService.getAppointmentDetails( appointmentRequestId );
		
		assertNotEquals(null, appointment2);
	}
	
	@Test(expected=AppointmentException.class)
	public void testGetAppointmentStatus2() throws AppointmentException 
	{
		AppointmentDetails appointment
		= appointmentService.getAppointmentDetails(-1000);
		
	}

	@Test(expected=AppointmentException.class)
	public void testEmailValidation() throws AppointmentException 
	{
	AppointmentDetails appointment = new AppointmentDetails();
		
	appointment.setName("Bhagyashri");
	appointment.setPhoneNo(7206333344L);
	appointment.setEmailId("bhagyashrigmail.com");
	appointment.setGender("female");
	appointment.setProblemName("heart");
	appointment.setDate(convertToDate("04-12-2018"));
		
		
		appointmentService.addAppointment( appointment );
	}
	
//	@Test(expected=AppointmentException.class)
//	public void testAgeValidation() throws AppointmentException 
//	{
//	AppointmentDetails appointment = new AppointmentDetails();
//		
//	appointment.setName("Bhagyashri");
//	appointment.setPhoneNo(7206333344L);
//	appointment.setEmailId("bhagyashri@gmail.com");
//	appointment.setGender("female");
//	appointment.setAge(1000);
//	appointment.setProblemName("heart");
//	appointment.setDate(convertToDate("04-12-2018"));
//		
//				
//		appointmentService.addAppointment( appointment );
//	}
	
	@Test(expected=AppointmentException.class)
	public void testPhoneValidation() throws AppointmentException 
	{
	AppointmentDetails appointment = new AppointmentDetails();
		
	appointment.setName("Bhagyashri");
	appointment.setPhoneNo(720633L);
	appointment.setEmailId("bhagyashrigmail.com");
	appointment.setGender("female");
	appointment.setProblemName("heart");
	appointment.setDate(convertToDate("04-12-2018"));
		
		appointmentService.addAppointment( appointment );
	}
	
	@Test(expected=AppointmentException.class)
	public void testGenderValidation() throws AppointmentException 
	{
	AppointmentDetails appointment = new AppointmentDetails();
		
	appointment.setName("Bhagyashri");
	appointment.setPhoneNo(720633L);
	appointment.setEmailId("bhagyashrigmail.com");
	appointment.setGender("femle");
	appointment.setProblemName("heart");
	appointment.setDate(convertToDate("04-12-2018"));
		
		appointmentService.addAppointment( appointment );
	}
	
	@Test(expected=AppointmentException.class)
	public void testDateValidation() throws AppointmentException 
	{
	AppointmentDetails appointment = new AppointmentDetails();
		
	appointment.setName("Bhagyashri");
	appointment.setPhoneNo(720633L);
	appointment.setEmailId("bhagyashrigmail.com");
	appointment.setGender("female");
	appointment.setProblemName("heart");
	appointment.setDate(convertToDate("04-05-2018"));		
		appointmentService.addAppointment( appointment );
	}

}
