package com.capgemini.core.doctor.util;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.doctor.bean.DoctorsDetails;


public class DoctorDBUtil 
{
	private List<DoctorsDetails> docdetails=new ArrayList<DoctorsDetails>();
	{
		docdetails.add(new DoctorsDetails("akhil","heart"));
		docdetails.add(new DoctorsDetails("bhagyashri","gyna"));
		docdetails.add(new DoctorsDetails("harshal","ENT"));
		docdetails.add(new DoctorsDetails("ayush","Diabetes"));
		docdetails.add(new DoctorsDetails("akshat","Dermatology"));
		
	}
	
	public List<DoctorsDetails> getDocdetails() {
		return docdetails;
	}
	public void setDocdetails(List<DoctorsDetails> docdetails) {
		this.docdetails = docdetails;
	}
	
	

}
