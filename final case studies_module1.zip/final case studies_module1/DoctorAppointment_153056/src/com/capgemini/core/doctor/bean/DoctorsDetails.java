package com.capgemini.core.doctor.bean;

public class DoctorsDetails 
{
	private String DoctorName;
	private String DoctorSpecialization;
	
	public DoctorsDetails() {
		super();
	}
	
	

	public DoctorsDetails(String doctorSpecialization) {
		super();
		DoctorSpecialization = doctorSpecialization;
	}



	public DoctorsDetails(String doctorName, String doctorSpecialization) {
		super();
		DoctorName = doctorName;
		DoctorSpecialization = doctorSpecialization;
	}

	public String getDoctorName() {
		return DoctorName;
	}

	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}

	public String getDoctorSpecialization() {
		return DoctorSpecialization;
	}

	public void setDoctorSpecialization(String doctorSpecialization) {
		DoctorSpecialization = doctorSpecialization;
	}

	@Override
	public String toString() {
		return "DoctorsList [DoctorName=" + DoctorName + ", DoctorSpecialization=" + DoctorSpecialization + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((DoctorSpecialization == null) ? 0 : DoctorSpecialization.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DoctorsDetails other = (DoctorsDetails) obj;
		if (DoctorSpecialization == null) {
			if (other.DoctorSpecialization != null)
				return false;
		} else if (!DoctorSpecialization.equals(other.DoctorSpecialization))
			return false;
		return true;
	}
	
	
	

}
