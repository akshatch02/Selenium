package com.capgemini.core.doctor.model;

import java.util.List;



import com.capgemini.core.doctor.bean.AppointmentDetails;
import com.capgemini.core.doctor.bean.DoctorsDetails;
import com.capgemini.core.doctor.exception.AppointmentException;
import com.capgemini.core.doctor.util.DoctorDBUtil;
import com.capgemini.core.doctor.util.PatientDBUtil;




public class AppointmentDAOImpl implements AppointmentDAO
{
	
	
	private List<AppointmentDetails> appointmentDetails;
	private List<DoctorsDetails> doctorDetails;
	
	private PatientDBUtil dbUtil=new PatientDBUtil();
	private DoctorDBUtil docdbUtil=new DoctorDBUtil();

	private int AppointmentId=1000;
	
	
	public AppointmentDAOImpl() 
	{
		appointmentDetails=dbUtil.getAppointmentdetails();
		doctorDetails=docdbUtil.getDocdetails();
	}
	
	public int generateAppointmentId()
	{
		return ++AppointmentId;
	}

	@Override
	public int addAppointment(AppointmentDetails details) throws AppointmentException {
		
		int appId = generateAppointmentId();
		
		details.setAppointmentId(appId);
		
		String problem=details.getProblemName();
		int index=doctorDetails.indexOf(new DoctorsDetails(problem));
		
		if(index==-1)
		{
			details.setAppointmentId(appId);
			details.setName(details.getName());
			details.setAppointmentStatus("DISAPPROVED");
			appointmentDetails.add(details);
			
			System.out.println("Patient Name: "+details.getName());
			System.out.println("Appointment Status: "+details.getAppointmentStatus());
			System.out.println("Doctor Name: "+" ");
			System.out.println("Appointment Date: "+" ");
			
			System.out.println("Your appointment is disapproved having request Id: "+appId);
		}
		else
		{
			DoctorsDetails doc=doctorDetails.get(index);
			String docname=doc.getDoctorName();
			details.setAppointmentId(appId);
			details.setName(details.getName());
			details.setAppointmentStatus("APPROVED");
			details.setDocName(docname);
			details.setDate(details.getDate());
			appointmentDetails.add(details);
			
			System.out.println("Patient Name: "+details.getName());
			System.out.println("Appointment Status: "+details.getAppointmentStatus());
			System.out.println("Doctor Name: "+ details.getDocName());
			System.out.println("Appointment Date: "+details.getDate());
			
			System.out.println("Your appointment is approved having request Id: "+appId);
		}
		
		
		return appId;
	}

	@Override
	public AppointmentDetails getAppointmentDetails(int id) throws AppointmentException 
	{
		
		
		
		int index=appointmentDetails.indexOf(new AppointmentDetails(id));
		if(index== -1)
		{
		
			throw new AppointmentException("appointment not found");
		}
		else
			
		return appointmentDetails.get(index);
				
	}

}
