package com.capgemini.core.doctor.util;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.doctor.bean.AppointmentDetails;


public class PatientDBUtil 
{
	private List<AppointmentDetails> appointmentdetails=new ArrayList<AppointmentDetails>();
	{
		
		
	}
	
	
	public List<AppointmentDetails> getAppointmentdetails() {
		return appointmentdetails;
	}
	public void setAppointmentdetails(List<AppointmentDetails> appointmentdetails) {
		this.appointmentdetails = appointmentdetails;
	}
	
	

}
