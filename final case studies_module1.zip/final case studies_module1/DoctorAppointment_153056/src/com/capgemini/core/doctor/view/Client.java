package com.capgemini.core.doctor.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Scanner;



import com.capgemini.core.doctor.bean.AppointmentDetails;
import com.capgemini.core.doctor.exception.AppointmentException;
import com.capgemini.core.doctor.service.AppointmentService;
import com.capgemini.core.doctor.service.AppointmentServiceImpl;

public class Client 
{
	private AppointmentService appointmentService;

	public Client() 
	{
		appointmentService=new AppointmentServiceImpl();
		
	}
	
	
	public void menu()
	{
		System.out.println("1) Book an appointment");
		System.out.println("2) View Booking Details");
		System.out.println("0) Exit Application");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please select an option: ");
		int choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:
			
			AppointmentDetails appDetails=new AppointmentDetails();
			
			System.out.println(" Enter patient name: ");
			String name=sc.next();
			
			System.out.println(" Enter patient phone number: ");
			long num=sc.nextLong();
			
			System.out.println(" Enter patient emailID: ");
			String emailid=sc.next();
			
			System.out.println(" Enter patient gender: ");
			String gen=sc.next();
			
			System.out.println(" Enter patient problem name: ");
			String problemname=sc.next();
			
			System.out.println(" Enter patient appointment date(dd-MM-yyyy)");
			String appdate=sc.next();
			
			
			
			appDetails.setName(name);
			appDetails.setPhoneNo(num);
			appDetails.setEmailId(emailid);
			appDetails.setGender(gen);
			appDetails.setProblemName(problemname);
			appDetails.setDate(convertToDate(appdate));
			
			try {
				int appId=appointmentService.addAppointment(appDetails);
			} 
			catch (AppointmentException e) 
			{
				
				e.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
				
			}
			break;
			
		case 2:
			
			System.out.println("Enter employee ID to view details: ");
			int appId=sc.nextInt();
			
			try 
			{
				appDetails=appointmentService.getAppointmentDetails(appId);
				
				System.out.println("Patient's Name: "+appDetails.getName());
				System.out.println("Appointment Status: "+appDetails.getAppointmentStatus());
				System.out.println("Doctor Name: "+appDetails.getDocName());
				System.out.println("Appointment Date: "+appDetails.getDate());
			} 
			catch (AppointmentException e) 
			{
				
				e.printStackTrace();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				
			}
			break;

		case 0:
			System.out.println("GoodBye");
			System.exit(0);
			break;
			
			
		}
		
		
		
		
		

}
	
	public Date convertToDate(String dateInString)
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate localdate=LocalDate.parse(dateInString,formatter);
		java.util.Date date=java.sql.Date.valueOf(localdate);
		return date;
	}
	
	public static void main(String[] args) {
		
		
		Client client=new Client();
		
		
		while(true)
			client.menu();
	}
}
