package com.cg.redbus.stepedefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.redbus.bean.BookingPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RedBusStepDefinition {

	private WebDriver driver;
	private BookingPage bookingpage;

	@Before()
	public void SetupStepEnv() {

		System.out.println("Env1");
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^user wants to book bus ticket$")
	public void user_wants_to_book_bus_ticket() throws Throwable {
		driver.get("https://www.redbus.in");
		bookingpage = new BookingPage();
		PageFactory.initElements(driver, bookingpage);
	}

	@When("^user opens redBus app home page by entering url 'https://www\\.redbus\\.in' And enter details$")
	public void user_opens_redBus_app_home_page_by_entering_url_https_www_redbus_in_And_enter_details()
			throws Throwable {

	
		bookingpage.setFrom1("Pune");
		
		bookingpage.setTo1("Nagpur");

		bookingpage.clickodate1();
		bookingpage.clickodate2();
		
		bookingpage.clickrdate1();
		bookingpage.clickrdate2();
		Thread.sleep(500);
		
		bookingpage.clickfrom2();
		bookingpage.clickto2();
		Thread.sleep(500);
		
		bookingpage.clickserachbutton();
		
		Thread.sleep(5000);
		bookingpage.clickviewbutton();
		
	}

	@Then("^booking is done$")
	public void booking_is_done() throws Throwable {

	}

}
