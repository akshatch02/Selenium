package com.cg.redbus.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BookingPage {
	
	//first page
	@FindBy(how= How.XPATH, xpath="//*[@id=\"src\"]")
	WebElement from1;
	@FindBy(how = How.XPATH, xpath="//*[@id=\"search\"]/div/div[1]/div/ul/li[1]")
	WebElement from2;

	@FindBy(how = How.XPATH, xpath="//*[@id=\"dest\"]")
	WebElement to1;
	@FindBy(how = How.XPATH, xpath="//*[@id=\"search\"]/div/div[2]/div/ul/li")
	WebElement to2;
	
	@FindBy(how = How.XPATH, xpath="//*[@id=\"search\"]/div/div[3]/span")
	WebElement odate1;
	@FindBy(how = How.XPATH, xpath="//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[4]/td[2]")
	WebElement odate2;
	
	@FindBy(how = How.XPATH, xpath="//*[@id=\"search\"]/div/div[4]/span")
	WebElement rdate1;
	@FindBy(how = How.XPATH, xpath="//*[@id=\"rb-calendar_return_cal\"]/table/tbody/tr[5]/td[2]")
	WebElement rdate2;
	
	@FindBy(how = How.ID, id="search_btn")
	WebElement searchButton;
	
	
	//second page
	
	@FindBy(how = How.XPATH, xpath="//*[@id=\"8436880\"]/div/div[2]/div[1]")
	WebElement viewbutton;
	
	
	//firstpage
	public String getFrom1() {
		return this.from1.getAttribute("value");
	}
	public void setFrom1(String from1) {
		this.from1.sendKeys(from1);
	}
	public String getTo1() {
		return this.to1.getAttribute("value");
	}
	public void setTo1(String to1) {
		this.to1.sendKeys(to1);
	}
	
	
	public void clickfrom1()
	{
		from1.click();
	}
	
	public void clickfrom2()
	{
		from2.click();
	}
	
	public void clickto1()
	{
		to1.click();
	}
	public void clickto2()
	{
		to2.click();
	}
	
	public void clickodate1()
	{
		odate1.click();
	}
	public void clickodate2()
	{
		odate2.click();
	}
	
	public void clickrdate1()
	{
		rdate1.click();
	}
	public void clickrdate2()
	{
		rdate2.click();
	}
	
	public void clickserachbutton()
	{
		searchButton.click();
	}
	
	//secondpage
	
	public void clickviewbutton() {
		viewbutton.click();
	}
	
}
