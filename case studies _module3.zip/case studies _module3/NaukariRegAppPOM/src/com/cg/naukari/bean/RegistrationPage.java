package com.cg.naukari.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {

	//first page
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"p0widget\"]/div/div[1]/div/input")
	WebElement regbutton;

	@FindBy(how = How.XPATH, xpath = "//*[@id=\"flowBifurcation\"]/div[2]/form/div[1]/div")
	WebElement fresherbutton;

	@FindBy(how = How.ID, id = "fname")
	WebElement name;
	@FindBy(how = How.ID, id = "email")
	WebElement email;
	@FindBy(how = How.NAME, name = "password")
	WebElement password;
	@FindBy(how = How.NAME, name = "number")
	WebElement mobilenumber;
	@FindBy(how = How.NAME, name = "city")
	WebElement city;
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"basicDetailForm\"]/resman-uploader/div/div[1]/span[1]/input")
	WebElement resume;

	@FindBy(how = How.NAME, name = "basicDetailSubmit")
	WebElement registerbutton;
	
	
	//second page
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[1]/ul/li/div/label/input")
	WebElement qual1;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li/div/div/span")
	WebElement qual2;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-course/div/div[1]/div/div/div[1]/ul/li/div/label/input")
	WebElement course1;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-course/div/div[1]/div/div/div[2]/ul/li/div/div/span")
	WebElement course2;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-spec/div/div[1]/div/div/div[1]/ul/li/div/label/input")
	WebElement spec1;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-spec/div/div[1]/div/div/div[2]/ul/li/div/div/span")
	WebElement spec2;
	
	@FindBy(how=How.NAME, name="institute_0")
	WebElement instname;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/div/div/div/div/label[1]")
	WebElement type;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-passing/div/div[1]/div/div/div[1]/ul/li/div/label/input")
	WebElement year1;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-passing/div/div[1]/div/div/div[2]/ul/li/div/div/span")
	WebElement year2;
	
	@FindBy(how=How.NAME, name="keyskills")
	WebElement skills;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"educationDetailForm\"]/div/div/div/button")
	WebElement submitbutton;
	
	

	public RegistrationPage() {

	}

	//first page
	public String getName() {
		return this.name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPassword() {
		return this.password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getMobilenumber() {
		return this.mobilenumber.getAttribute("value");
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber.sendKeys(mobilenumber);
	}

	public String getCity() {
		return this.city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getResume() {
		return this.resume.getAttribute("value");
	}

	public void setResume(String resume) {
		this.resume.sendKeys(resume);
	}

	
	public void clickRegbutton()
	{
		regbutton.click();
	}
	public void clickFresherButton()
	{
		fresherbutton.click();
	}
	public void clickRegistrationbutton()
	{
		registerbutton.click();
	}

	
	
	
	//second page
	public String getInstname() {
		return this.instname.getAttribute("value");
	}

	public void setInstname(String instname) {
		this.instname.sendKeys(instname);
	}

	public String getSkills() {
		return this.skills.getAttribute("value");
	}

	public void setSkills(String skills) {
		this.skills.sendKeys(skills);
	}
	

	
	public void clickqual1()
	{
		qual1.click();
	}
	
	public void clickqual2()
	{
		qual2.click();
	}
	
	public void clickcourse1()
	{
		course1.click();
	}
	
	public void clickcourse2()
	{
		course2.click();
	}
	
	public void clickspec1()
	{
		spec1.click();
	}
	
	public void clickspec2()
	{
		spec2.click();
	}
	
	public void clicktype()
	{
		type.click();
	}
	public void clickyear1()
	{
		year1.click();
	}
	public void clickyear2()
	{
		year2.click();
	}
	
	
	
	public void clicksubmitbutton()
	{
		submitbutton.click();
	}
	
}
