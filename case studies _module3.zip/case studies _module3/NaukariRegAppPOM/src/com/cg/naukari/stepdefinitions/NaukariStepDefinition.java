package com.cg.naukari.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cg.naukari.bean.RegistrationPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class NaukariStepDefinition {

	private WebDriver driver;
	private RegistrationPage registrationpage;

	@Before()
	public void SetupStepEnv() {

		System.out.println("Env1");
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^user is on 'www\\.naukari\\.com' page$")
	public void user_is_on_www_naukari_com_page() throws Throwable {
		driver.get("https://www.naukri.com/");
		registrationpage = new RegistrationPage();
		PageFactory.initElements(driver, registrationpage);
	}

	@When("^user click on register with us And  enter details$")
	public void user_click_on_register_with_us_And_enter_details() throws Throwable {
	
		//first page
		registrationpage.clickRegbutton();
		registrationpage.clickFresherButton();
			
		registrationpage.setName("vhhjhjjshhh");
		registrationpage.setEmail("jairtertbghghjh759562@gmail.com");
		registrationpage.setPassword("jainnnndfsdseht82345sh");
		registrationpage.setMobilenumber("7052885563");
		registrationpage.setCity("Pune");
		registrationpage.setResume("D:\\aaaaaaaa\\hello.pdf");
		
		registrationpage.clickRegistrationbutton();
		
		WebDriverWait wait = new WebDriverWait(driver, 100);
		
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.name("qualification_0")));
		
		//second page
		
		registrationpage.clickqual1();
		registrationpage.clickqual2();
		
		registrationpage.clickcourse1();
		registrationpage.clickcourse2();
		
		registrationpage.clickspec1();
		registrationpage.clickspec2();
		
		registrationpage.clicktype();
		
		registrationpage.clickyear1();
		registrationpage.clickyear2();
		
		
		registrationpage.setInstname("YCCE");
		registrationpage.setSkills("xyz");
		
		registrationpage.clicksubmitbutton();
		
		
		
	}

	@Then("^registration is successfully done$")
	public void registration_is_successfully_done() throws Throwable {

	}

}
