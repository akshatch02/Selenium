package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyAppLoginPageStepDefination {
	
	private WebDriver driver;
	private LoginPage loginPage;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
	}
	@Given("^User is on MyApp Login Page$")
	public void user_is_on_MyApp_Login_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("D:\\BDDUsingCucumber\\LoginSir\\MyApp\\LoginPage.html");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}

	@When("^User Click on 'Sigin In' without entring 'username'$")
	public void user_Click_on_Sigin_In_without_entring_username() throws Throwable {
		loginPage.setUsername("");
		loginPage.clickSignIn();
		
	}

	@Then("^'Plz Enter UserName' message should display$")
	public void plz_Enter_UserName_message_should_display() throws Throwable {
		String expectedMessage="Plz Enter UserName";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Click on 'Sigin In' without entring 'password'$")
	public void user_Click_on_Sigin_In_without_entring_password() throws Throwable {
	   driver.switchTo().alert().dismiss();
		loginPage.setUsername("SaSaSa");
		loginPage.setPassword("");
		loginPage.clickSignIn();
	}

	@Then("^'Plz Enter Password' message should display$")
	public void plz_Enter_Password_message_should_display() throws Throwable {
		String expectedMessage="Plz Enter Password";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^User Click on 'Sigin In'  with invalid credentials$")
	public void user_Click_on_Sigin_In_with_invalid_credentials() throws Throwable {
		 
			loginPage.setUsername("SaSaSa");
			loginPage.setPassword("ABC");
			loginPage.clickSignIn();
	}

	@Then("^'UserName or Password is incorrect' message should display$")
	public void username_or_Password_is_incorrect_message_should_display() throws Throwable {
		String expectedMessage="UserName or Password is incorrect";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^User Click on 'Sigin In'  with Valid credentials$")
	public void user_Click_on_Sigin_In_with_Valid_credentials() throws Throwable {
			loginPage.setUsername("Satish");
			loginPage.setPassword("HelloWorld");
			loginPage.clickSignIn();
	}

	@Then("^'Welcome UserName ' message should display and Welcome Page should load with title 'Welcome To MyApp'$")
	public void welcome_UserName_message_should_display_and_Welcome_Page_should_load_with_title_Welcome_To_MyApp() throws Throwable {
		String expectedMessage="Welcome Satish";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		 driver.switchTo().alert().dismiss();
		 String expectedPageTitle="Welcome To MyApp";
		 String actualPageTitle=driver.getTitle();
		 Assert.assertEquals(expectedPageTitle, actualPageTitle);
	}


}
