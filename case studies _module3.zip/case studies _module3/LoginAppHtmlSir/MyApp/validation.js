function validate(){
    if(loginFrm.username.value==""){
        alert("Plz Enter UserName")
        return false;
    }
    else if (loginFrm.password.value==""){
        alert("Plz Enter Password")
        return false;
    }
    else if (loginFrm.username.value!="Satish"||loginFrm.password.value!="HelloWorld"){
        alert("UserName or Password is incorrect")
        return false;
    }
    else if(loginFrm.username.value=="Satish"&&loginFrm.password.value=="HelloWorld"){
         alert("Welcome "+loginFrm.username.value);
        window.location="WelcomePage.html"
    }
    
    
}