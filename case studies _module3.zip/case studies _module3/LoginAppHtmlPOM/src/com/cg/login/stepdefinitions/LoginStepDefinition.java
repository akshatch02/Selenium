package com.cg.login.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.login.beans.LoginPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {
	private WebDriver driver;
	private LoginPage loginpage;

	@Before()
	public void SetupStepEnv() {

		System.out.println("Env1");
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^user wants to signup on myloginApp$")
	public void user_wants_to_signup_on_myloginApp() throws Throwable {
		//driver = new ChromeDriver();
		driver.get("D:\\BDDUsingCucumber\\LoginApp\\login.html");
		loginpage = new LoginPage();
		PageFactory.initElements(driver, loginpage);
	}

	@When("^user do not enter username$")
	public void user_do_not_enter_username() throws Throwable {
		loginpage.setUsername("");
		loginpage.clickSubmitbutton();
	}

	@Then("^display message 'plz enter username'$")
	public void display_message_plz_enter_username() throws Throwable {
		String expectedMessage = "Plz Enter UserName";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1500);
	}

	@When("^user do not enter password$")
	public void user_do_not_enter_password() throws Throwable {
		driver.switchTo().alert().dismiss();
		loginpage.setUsername("Bhagyashri");
		loginpage.setPassword("");
		loginpage.clickSubmitbutton();
	}

	@Then("^display message 'plz enter password'$")
	public void display_message_plz_enter_password() throws Throwable {
		String expectedMessage = "Plz Enter Password";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1500);
		driver.close();
	}

	@When("^user enter invalid username or password$")
	public void user_enter_invalid_username_or_password() throws Throwable {
		loginpage.setPassword("xyz23");
		loginpage.setUsername("bhgya");
		loginpage.clickSubmitbutton();
	}

	@Then("^display message 'invalid username or password'$")
	public void display_message_invalid_username_or_password() throws Throwable {
		String expectedMessage = "UserName or Password is incorrect";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(1500);
		driver.close();
	}

	@When("^user enter valid username and password$")
	public void user_enter_valid_username_and_password() throws Throwable {
		loginpage.setUsername("Bhagyashri");
		loginpage.setPassword("xyz23");
		loginpage.clickSubmitbutton();
	}

	@Then("^display message success$")
	public void display_message_success() throws Throwable {
		String expectedMessage = "Welcome to success page";
		String actualMessage = driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
	}

}
