package com.cg.login.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {

	@FindBy(how = How.NAME, name="userid")
	WebElement username;
	
	@FindBy(how = How.NAME, name="password")
	WebElement password;
	
	@FindBy(how = How.NAME, name="submit")
	WebElement sumbitbutton;
	
	public LoginPage() {
		
	}

	public String getUsername() {
		return this.username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return this.password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	
	
	public void clickSubmitbutton()
	{
		this.sumbitbutton.click();
	}
	
	
}
